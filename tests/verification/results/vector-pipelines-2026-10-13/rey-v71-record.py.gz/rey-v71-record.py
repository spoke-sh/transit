"""Assemble selected qualification only after exact inventory completion."""
import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/home/alex/workspace/rupurt/rey');cache=root/'.cache/vectorization-completion';control=Path('/var/tmp/rey-v71-qual-ehws5ccq/src/.cache/ci/clean')
runtime='5b3d1ba65a8e918996be0790494aa01914aeacc4';fixture='3e1f359a5484fbab370965eee4ee868aa7cf0adb'
def read(path):return json.loads(path.read_text())
def log(path):
 path=Path(path);data=path.read_bytes()
 return dict(local_path=str(path.relative_to(root)) if path.is_relative_to(root) else str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
suite=read(root/'tests/verification/suite.json')['lanes'];lanes={};runs=[]
def add(lane,record):
 assert record['completed'],(lane,record.get('active_task'))
 assert record['tasks']==[r['task'] for r in record['results']]
 assert all(r['exit_code']==0 and not r.get('tracked_dirty_after',False) for r in record['results'])
 for r in record['results']:
  if 'log' in r:
   saved=log(root/r['log']);assert saved['sha256']==r['sha256'];r['log']=saved;r.pop('sha256')
 lanes.setdefault(lane,[]).extend(r['task'] for r in record['results']);record['lane']=lane;runs.append(record)
for lane in ['core','experience','launchers']:
 rev=runtime if lane=='core' else ('530f31e1529d50ba1910d23333b5e079d8ebc28d' if lane=='launchers' else '83bc1e2ec3af1c61c703ea604931e60d3a151883')
 lane_control=Path(read(cache/'launchers-control-final.json')['path'])/'.cache/ci/clean' if lane=='launchers' else control
 matches=[]
 for path in lane_control.glob(rev[:12]+'-*/'+lane+'.meta.json'):
  meta=read(path)
  if meta['completed']:matches.append((path,meta))
 assert len(matches)==1,(lane,matches)
 path,meta=matches[0];results=read(path.with_name(lane+'.json'))
 assert meta['expected_tasks']==suite[lane]
 add(lane,dict(kind='complete committed-source clean lane',source_revision=meta['revision'],command='nix develop --command just ci-clean --lane '+lane,completed=True,tasks=meta['expected_tasks'],meta=meta,results=results,log=log(cache/('clean-core-5b3d.log' if lane=='core' else 'clean-launchers-530f.log' if lane=='launchers' else 'clean-'+lane+'-83bc.log'))))
for lane,names in [('growth',['growth-prefix','growth-remainder']),('bindings',['prefix','rust-ruby','c-java','dotnet-final','beam','interop-tail'])]:
 for name in names:
  record=read(cache/'shards'/(name+'.json'));record['record_name']=name
  if name=='dotnet-final':
   record['diagnostic_environment']={'DOTNET_DbgEnableMiniDump':'1','DOTNET_DbgMiniDumpType':'2','DOTNET_DbgMiniDumpName':'/var/tmp/rey-v71-dotnet-dumps/crash.%p.dmp'}
  if name.endswith('prefix') or name=='prefix':
   record['log']=log(cache/('clean-growth-5b3d.log' if lane=='growth' else 'clean-bindings-5b3d.log'))
  else:
   record['command']='pristine clone; nix develop --command just transit-board::install; nix develop .#bindings --command just <each task in order>'
  add(lane,record)
for lane,tasks in lanes.items():
 assert len(tasks)==len(set(tasks)) and set(tasks)==set(suite[lane]),(lane,tasks)
assert sum(map(len,lanes.values()))==79
checks=[]
for command,revision,filename in [
 ('just check',runtime,'check-row-cache-final.log'),
 ('just check',fixture,'check-3e1f.log'),
 ('just check','530f31e1529d50ba1910d23333b5e079d8ebc28d','check-sdk-final.log'),
 ('just check','83bc1e2ec3af1c61c703ea604931e60d3a151883','check-83bc.log'),
 ('just test::unified-query',runtime,'focused-unified-5b3d.log'),
 ('just test::flight','366cda49','focused-flight-366c.log'),
 ('just test::relational','366cda49','focused-relational-366c.log'),
 ('just transit-board::browser-install; just transit-board::relational-browser; just check','08335068 (diagnostic key order changed to ae536f99 during run)','final-workspace-checks.log'),
 ('(transit-fuze) zig build test -Doptimize=ReleaseSafe','5b3d1ba6','row-cache-ownership.log'),
 ('(transit-fuze) zig build test -Doptimize=ReleaseSafe','366cda49','randomized-tests.log'),
 ('zig build test -Doptimize=ReleaseSafe','20a1ef64','worker-dispatch-final.log')]:
 full_revision=subprocess.check_output(['git','rev-parse',revision.split()[0]],cwd=root,text=True).strip()
 checks.append(dict(command=command,source_revision=full_revision,source_note=revision if ' ' in revision else None,exit_code=0,log=log(cache/filename)))
failures=[
 ('clean-core.log','Initial explicit worker stacks were too small for Debug thread-local storage; corrected bootstrap/stack accounting and subsequent core/full checks pass.'),
 ('relational-focused.log','The standalone relational task bypassed the package interface and lacked its imported Arrow module. Subsequent direct-link attempts also lacked the isolated ISA object; the task now links the owning package and the focused proof passes.'),
 ('clean-core-fixed.log','The newly isolated source-provenance fixture needed zig fmt; corrected formatting and reran clean core.'),
 ('clean-experience-docs.log','Board query fixture provisioning exceeded its existing 60-second deadline during concurrent durable proofs; no query execution result from this attempt.'),
 ('clean-experience-retry.log','Second provisioning timeout at the same unchanged deadline; not a pass.'),
 ('clean-growth-5b3d.log','The cold maintenance fixture let its held snapshot idle past its renewable lease. The fixture now explicitly renews the same cut while preserving the hard deadline. First fifteen tasks passed; corrected remaining tasks ran in a new pristine checkout.'),
 ('clean-bindings-5b3d.log','Intentionally interrupted after the first five tasks completed; remaining thirteen unchanged tasks run in pristine subsets. This is not a completed full lane.'),
 ('shards/dotnet-bindings-dotnet-sdk-test.log','Installed .NET requester example terminated with SIGSEGV after a durable continuation. No crash dump was produced. The kernel recorded execution at an unmapped address. A new installed mapping regression fails deterministically against the old loader. Commit 48f6adff retains bounded code images through detached worker exit, as already required by the pinned runtime in Rust. The diagnostic old-loader retry was interrupted; corrected packages run in a new pristine checkout.'),
 ('shards/dotnet-fixed-bindings-dotnet-sdk-test.log','Corrected .NET Station/HTTP/gRPC schedules passed, but the final shared Table bridge fixture treated one transient catalog next-read AuthorityTimeout as terminal. Commit 83bc1e2e retries only observations within the unchanged call/operation deadlines; it does not retry or reconstruct submissions. The full .NET task reruns in a new pristine checkout.'),
 ('check-a4af.log','Documentation ownership test rejected repository-tool commands in the public Internals page. The page now links reproduction through the proof owners; no test was relaxed.'),
 ('focused-5b3d.log','A variadic just recipe consumed subsequent task names as arguments; reran the three focused tasks individually.')]
record=dict(issue=71,result='passed',dotnet_lifetime=dict(revision='48f6adff6422f8ef3aac29eba3a00a409550e4df',kernel_log=log(cache/'dotnet-original-kernel.log'),negative_control=log(cache/'dotnet-lifetime-negative.log'),negative_control_scope='The new real-I/O retention assertion, before adding capacity coverage, fails against original packages at 3e1f359a with Native code was unloaded or duplicated. This is deterministic evidence of unsafe unloading; no original core stack was available.',raw_positive=log(cache/'dotnet-lifetime-raw-complete.log'),raw_positive_scope='Includes final sixteen-image admission, repeated I/O, changed/missing override checks and existing exact recovery/cancellation/current-denial schedule.'),runtime_revision=runtime,base_revision='243df508ec22705c64b02ba41c4b3970f53305ab',snapshot_fixture_revision=fixture,qualification_head='83bc1e2ec3af1c61c703ea604931e60d3a151883',ordinary_task_count=79,coverage={lane:len(tasks) for lane,tasks in lanes.items()},inventory=log(root/'tests/verification/suite.json'),qualification_method='All 79 unchanged ordinary tasks passed from pristine committed-source clones. Core, experience and launchers are complete ci-clean lanes; growth and bindings combine explicitly recorded disjoint prefixes/subsets. No incomplete full lane is labeled passed.',runs=runs,focused_checks=checks,measurements=dict(account='../../fuze_benchmarks/results/2026-10-13-pipelines/README.md',wider_checks=24,original_checks=115,violations=0,cpu_probes='../../fuze_benchmarks/results/2026-10-13-pipelines/release-cpu-dispatch.json',nehalem=dict(passed=312,skipped=1,failed=0,skip='Hardware-specific AVX2 execution only; separate forced dispatch rejection passes.')),retained_attempts=[dict(log=log(cache/name),outcome=outcome) for name,outcome in failures],orchestration_sources=[log(Path('/tmp')/name) for name in ['rey-v71-sdk-shard.py','rey-v71-qualification-shard.py','rey-v71-sdk-prefix.py','rey-v71-late-clean.py','rey-v71-launchers-run.py','rey-v71-record.py']],limits=['Qualification uses Linux x86_64 on a shared host; no new hardware profile or latency SLO.','Portable kernels and one worker remain defaults; forced AVX2 and additional workers are qualified choices, without a general speedup claim.','Relational kernels retain the original one-read/one-group-update quantum; no new join algorithm or multilane lookahead.','Hardware counters were denied; no missing counter is treated as measured.','The core query runtime stays at 5b3d1ba6. Later changes add qualification/evidence and fixture renewal. Commit 48f6adff separately fixes the .NET native loader lifetime exposed during qualification; corrected .NET and interop tasks identify that source. No later revision silently replaces the measurement revision.','Hosted execution status is reported separately in the PR.'])
maintenance=[]
for line in (cache/'shards/growth-remainder-test-relational-maintenance.log').read_text().splitlines():
 if line.startswith('{'):
  try: value=json.loads(line)
  except json.JSONDecodeError: continue
  if value.get('profile') in ['typed-table-native','maintained-ongoing-input']:maintenance.append(value)
assert any(v.get('held_snapshot_renewals',0)>0 for v in maintenance)
record['catalog_read_fixture_revision']='83bc1e2ec3af1c61c703ea604931e60d3a151883'
record['native_maintenance_observations']=maintenance
for filename,profile,key in [('growth-remainder-test-relational-exchanges.log','relational-exchange-native','native_exchange_observations')]:
 for line in (cache/'shards'/filename).read_text().splitlines():
  if line.startswith('{'):
   value=json.loads(line)
   if value.get('profile')==profile:record[key]=value
 assert key in record
archive=root/'tests/verification/results/vector-pipelines-2026-10-13'
archive.mkdir(exist_ok=True)
for entry in record['orchestration_sources']:
 path=Path(entry['local_path']);destination=archive/(path.name+'.gz')
 destination.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
 entry['archive']=str(destination.relative_to(archive.parent))
 entry['archive_sha256']=hashlib.sha256(destination.read_bytes()).hexdigest()
dest=root/'tests/verification/results/vector-pipelines-2026-10-13.json';dest.write_text(json.dumps(record,indent=2)+'\n');print(dest)
