import json,subprocess,time
from pathlib import Path
source=Path('/home/alex/workspace/rupurt/rey'); root=Path('/var/tmp/rey-v71-qual-ehws5ccq/src'); evidence=source/'.cache/vectorization-completion'; rev='83bc1e2ec3af1c61c703ea604931e60d3a151883'
ready=evidence/'shards/growth-remainder.json'
while True:
 if ready.exists():
  data=json.loads(ready.read_text())
  if data['completed']:
   assert all(r['exit_code']==0 for r in data['results']);break
 time.sleep(3)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
subprocess.run(['git','fetch','--quiet',str(source),rev],cwd=root,check=True)
subprocess.run(['git','checkout','--quiet','--detach',rev],cwd=root,check=True)
records=[]
for lane in ['experience']:
 log=evidence/('clean-'+lane+'-83bc.log');start=time.monotonic();print('RUN',lane,flush=True)
 with log.open('w') as output:
  result=subprocess.run(['nix','develop','--command','taskset','-c','16-23,40-47','just','ci-clean','--lane',lane],cwd=root,stdout=output,stderr=subprocess.STDOUT)
 records.append(dict(lane=lane,source_revision=rev,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),log=str(log)))
 (evidence/'late-clean.json').write_text(json.dumps(records,indent=2)+'\n')
 print('RESULT',records[-1],flush=True)
