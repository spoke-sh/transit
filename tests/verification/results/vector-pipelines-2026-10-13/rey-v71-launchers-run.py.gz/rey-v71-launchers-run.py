import json,subprocess,tempfile,time
from pathlib import Path
source=Path('/home/alex/workspace/rupurt/rey');rev='530f31e1529d50ba1910d23333b5e079d8ebc28d';base=source/'.cache/vectorization-completion'
root=Path(tempfile.mkdtemp(prefix='rey-v71-launch-',dir='/var/tmp'))/'src'
subprocess.run(['git','clone','--quiet','--local','--no-hardlinks','--no-checkout',str(source),str(root)],check=True)
subprocess.run(['git','checkout','--quiet','--detach',rev],cwd=root,check=True)
p=base/'launchers-control-final.json';record=dict(path=str(root),source_revision=rev,completed=False,command='nix develop --command taskset -c 12-15,36-39 just ci-clean --lane launchers');p.write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (base/'clean-launchers-530f.log').open('w') as log:
 result=subprocess.run(['nix','develop','--command','taskset','-c','12-15,36-39','just','ci-clean','--lane','launchers'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
record.update(completed=True,exit_code=result.returncode,seconds=round(time.monotonic()-start,2));p.write_text(json.dumps(record,indent=2)+'\n');print(record);raise SystemExit(result.returncode)
