import json,os,signal,time
from pathlib import Path
pid=3614910;process=Path('/proc')/str(pid);birth=(process/'stat').read_text().split()[21]
expected=['bindings::check','bindings::native','bindings::python-test','bindings::node-sdk-test','bindings::logical-test']
path=Path('/var/tmp/transit-ci-s6f0cwkn/src/.cache/ci/bindings.json')
while process.exists():
 assert (process/'stat').read_text().split()[21]==birth
 if path.exists():
  results=json.loads(path.read_text())
  if len(results)>=len(expected):
   prefix=results[:len(expected)]
   assert [r['task'] for r in prefix]==expected and all(r['exit_code']==0 for r in prefix)
   assert (process/'cmdline').read_bytes().replace(b'\0',b' ').decode().strip()=='just ci-clean --lane bindings'
   assert (process/'cwd').resolve()==Path('/var/tmp/rey-v71-qual-ehws5ccq/src') and os.getpgid(pid)==pid
   Path('/home/alex/workspace/rupurt/rey/.cache/vectorization-completion/shards/prefix.json').write_text(json.dumps(dict(source_revision='5b3d1ba65a8e918996be0790494aa01914aeacc4',completed=True,tasks=expected,results=prefix,scope='Five completed prefix tasks; the remaining tasks run in separate pristine checkouts. The original full lane is intentionally interrupted.'),indent=2)+'\n')
   os.killpg(pid,signal.SIGINT);print('Stopped original lane after completed five-task prefix',flush=True);break
 time.sleep(2)
