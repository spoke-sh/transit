"""Run an explicit subset of the unchanged ordinary inventory in a pristine clone."""
import argparse, hashlib, json, os, platform, subprocess, tempfile, time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--inside',action='store_true');p.add_argument('--lane',default='bindings');p.add_argument('--name',required=True);p.add_argument('--revision',required=True);p.add_argument('--root',type=Path);p.add_argument('--wait-file',type=Path);p.add_argument('tasks',nargs='+');a=p.parse_args()
source=Path('/home/alex/workspace/rupurt/rey');evidence=source/'.cache/vectorization-completion/shards';evidence.mkdir(exist_ok=True)
if not a.inside:
 while a.wait_file and not a.wait_file.exists():time.sleep(2)
 root=Path(tempfile.mkdtemp(prefix='rey-v71sdk-',dir='/var/tmp'));checkout=root/'src';(root/'tmp').mkdir()
 subprocess.run(['git','clone','--quiet','--local','--no-hardlinks','--no-checkout',str(source),str(checkout)],check=True)
 subprocess.run(['git','checkout','--quiet','--detach',a.revision],cwd=checkout,check=True)
 subprocess.run(['nix','develop','--command','just','transit-board::install'],cwd=checkout,check=True)
 command=['nix','develop','.#bindings','--command','env','TMPDIR='+str(root/'tmp'),'python3','-B',__file__,'--inside','--lane',a.lane,'--name',a.name,'--revision',a.revision,'--root',str(root),*a.tasks]
 raise SystemExit(subprocess.run(command,cwd=checkout).returncode)
checkout=a.root/'src';assert Path.cwd()==checkout
suite=json.loads((checkout/'tests/verification/suite.json').read_text())['lanes'][a.lane]
assert len(set(a.tasks))==len(a.tasks) and set(a.tasks)<=set(suite)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==a.revision
assert not subprocess.check_output(['git','status','--porcelain'])
record=dict(kind='pristine ordinary inventory subset',lane=a.lane,source_revision=a.revision,checkout=str(checkout),tasks=a.tasks,completed=False,active_task=None,results=[],runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),platform=platform.platform(),affinity=sorted(os.sched_getaffinity(0)))
destination=evidence/(a.name+'.json')
def save():
 temporary=destination.with_suffix('.tmp');temporary.write_text(json.dumps(record,indent=2)+'\n');temporary.replace(destination)
save()
for task in a.tasks:
 record['active_task']=task;save();print('RUN',task,flush=True);start=time.monotonic();log=evidence/(a.name+'-'+task.replace('::','-')+'.log')
 with log.open('w') as output:process=subprocess.run(['just',task],stdout=output,stderr=subprocess.STDOUT)
 dirty=bool(subprocess.check_output(['git','status','--porcelain','--untracked-files=no']))
 record['results'].append(dict(task=task,exit_code=process.returncode,seconds=round(time.monotonic()-start,2),tracked_dirty_after=dirty,log=str(log.relative_to(source)),sha256=hashlib.sha256(log.read_bytes()).hexdigest()));record['active_task']=None;save();print('RESULT',record['results'][-1],flush=True)
 if process.returncode or dirty:raise SystemExit(process.returncode or 1)
record['completed']=True;save();print('COMPLETE',a.name,flush=True)
