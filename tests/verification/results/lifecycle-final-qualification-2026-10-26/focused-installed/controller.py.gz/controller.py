from pathlib import Path
import datetime
import json
import os
import subprocess
import time

root = Path('/var/tmp/transit-ci-sqyg2wgh/src')
destination = Path('/var/tmp/transit-lifecycle-final-installed-tasks')
destination.mkdir(exist_ok=True)
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert source == 'a048b154f081d80dbbf2b57f70e3fb787d546ca1'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
suite = json.loads((root / 'tests/verification/suite.json').read_text())
tasks = suite['lanes']['experience'][5:]
assert tasks[0] == 'test::server-direct-tables'
record = dict(source_revision=source, merged_revision='4434047222851efa5e26cf661d66158df88c0171',
              identical_git_tree='90ce763836c21c92023a02019228375f976072ec',
              status='running', expected_tasks=tasks, results=[], active_task=None,
              started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              method='Explicit unchanged owning tasks from the preserved isolated clean checkout. The original clean experience lane failed server-logging before storage startup and remains failed; this is separate focused installed qualification, not a completed ci-clean lane.',
              environment={'TMPDIR': '/var/tmp/transit-ci-sqyg2wgh/tmp', 'NIX_CONFIG_append': 'eval-cache = false'})

def save():
    path = destination / 'report.json'
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(record, indent=2) + '\n')
    temporary.replace(path)

save()
environment = {k: v for k, v in os.environ.items() if not k.startswith('TRANSIT_') and k not in ('KUBECONFIG', 'LOG_LEVEL', 'LOG_FORMAT')}
environment['NIX_CONFIG'] = environment.get('NIX_CONFIG', '') + '\neval-cache = false\n'
started_suite = time.monotonic()
for index, task in enumerate(tasks):
    command = ['nix', 'develop', '.#bindings', '--command', 'env', 'TMPDIR=/var/tmp/transit-ci-sqyg2wgh/tmp', 'just', task]
    log = destination / f'{index:02d}-{task.replace("::", "-")}.log'
    record['active_task'] = dict(task=task, command=command, log=log.name)
    save()
    started = time.monotonic()
    print('Running', task, flush=True)
    with log.open('w') as output:
        result = subprocess.run(command, cwd=root, env=environment, stdout=output, stderr=subprocess.STDOUT)
    record['results'].append(dict(task=task, command=command, log=log.name, exit_code=result.returncode, seconds=round(time.monotonic()-started, 2)))
    record['active_task'] = None
    save()
    print(task, result.returncode, flush=True)
    if result.returncode:
        record.update(status='failed', seconds=round(time.monotonic()-started_suite, 2), finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        raise SystemExit(result.returncode)
record.update(status='passed', seconds=round(time.monotonic()-started_suite, 2), finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
save()
