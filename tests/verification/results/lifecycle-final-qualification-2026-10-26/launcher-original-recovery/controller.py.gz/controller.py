from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path('/var/tmp/transit-ci-sqyg2wgh/src')
sys.path.insert(0, str(root / 'launchers'))
from station_example import StationInstallation
from common import wait_for, lock

installation = StationInstallation('local', 'station-5f4f3b')
destination = Path('/var/tmp/transit-lifecycle-launcher-original-recovery')
destination.mkdir(exist_ok=True)
sequence = installation.path / 'operator/sequence.json'
original = sequence.read_bytes()
state = json.loads(original)
pending = state['pending']
assert state['sequence'] == 9 and pending['id'] == 'resource-coordinator' and pending['request']['sequence'] == 10
node = installation.artifacts.binary('transit-node')
record = dict(source_revision='a048b154f081d80dbbf2b57f70e3fb787d546ca1',
              method='Reopen the original directory and recover only the already-saved native command through the existing exact-retry helper. No new operation identity, SQL or subsequent provisioning. Compare accepted positions before and after recovery.',
              pending_id=pending['id'], sequence=10, status='running',
              command_kind=list(pending['request']['command']),
              node_sha256=hashlib.sha256(Path(node).read_bytes()).hexdigest(),
              original_operator_state_sha256=hashlib.sha256(original).hexdigest())
path = destination / 'report.json'
path.write_text(json.dumps(record, indent=2) + '\n')
with (destination / 'node.log').open('w') as log:
    child = subprocess.Popen([str(node), str(installation.path / 'bootstrap-node.json')], stdout=log, stderr=subprocess.STDOUT,
                             env=os.environ | {'LOG_FORMAT':'json', 'LOG_LEVEL':'info'})
    try:
        wait_for(installation.url + '/health')
        before = installation.native_query({'identity': {}})
        assert before['principal_sequence'] == 10 and before['position'] == 11
        record['before'] = before
        with lock(installation.path / 'operator/lock'):
            assert sequence.read_bytes() == original
            installation._flush(state)
        receipt = json.loads((installation.path / 'operator/receipts/resource-coordinator.json').read_text())
        assert receipt['request'] == pending['request'] and receipt['id'] == pending['id']
        assert receipt['receipt']['position'] == 10
        record['original_receipt'] = {'id':receipt['id'], 'position':receipt['receipt']['position'], 'same_request':True}
        after = installation.native_query({'identity': {}})
        assert after['position'] == before['position'] and after['principal_sequence'] == before['principal_sequence']
        record['after'] = after
        final = json.loads(sequence.read_text())
        assert final['sequence'] == 10 and final['pending'] is None
        record['operator_state'] = {'sequence':10, 'pending':None}
        record['status'] = 'original_receipt_recovered_without_new_acceptance'
    finally:
        child.terminate()
        try:
            child.wait(timeout=15)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=15)
        path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
