import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time

source = Path('/var/tmp/transit-ci-hequxq0w/src')
sys.path.insert(0, str(source / 'tests'))
import serving

directory = Path(tempfile.mkdtemp(prefix='transit-reactive-read-', dir='/var/tmp'))
record_path = Path('/var/tmp/transit-lifecycle-reactive-frozen-read.json')
calls = (directory / 'observations.jsonl').open('w', buffering=1)
record = dict(source_revision='717f5579362a1135d0623668faa6a58f3788c6b9',
              source=str(source), fixture=str(directory), status='running',
              method='Same compiled binaries; one frozen signed status read replaces repeated credential preparation in the fixture. Physical ext4 fixture retained; request timings captured. No deadline or runtime changes.', binaries=[])
names = [('c46c3d5ea0712c1ea79e4e1222164d51', 'transit-node'),
         ('10e86b3699c0dd1a8172785cde9cee2b', 'transit-serving-example'),
         ('629eeea725bba78fe8137c5177effacc', 'transit-query-host'),
         ('e9d3569cd54eab62c9c32cd108c6be38', 'transit-station-host')]
binaries = []
for key, name in names:
    path = source / '.zig-cache/o' / key / name
    record['binaries'].append(dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    binaries.append(str(path))
original_directory = tempfile.TemporaryDirectory
class Retained:
    def __enter__(self):
        return str(directory)
    def __exit__(self, *_):
        return False
def fixture_directory(*args, **kwargs):
    return Retained() if kwargs.get('prefix') == 'transit-serving-' else original_directory(*args, **kwargs)
tempfile.TemporaryDirectory = fixture_directory
original_post = serving.post
def observed_post(port, path, value, *args, **kwargs):
    started = time.monotonic()
    sample = dict(started=started, path=path)
    if 'query' in value:
        sample['action'] = next(iter(value['query']['kind']))
    elif 'request' in value:
        sample['action'] = next(iter(value['request']['command']))
    try:
        result = original_post(port, path, value, *args, **kwargs)
        sample['outcome'] = 'returned'
        if isinstance(result, tuple):
            sample['status'] = result[0]
            if isinstance(result[1], dict):
                sample['stage'] = result[1].get('stage')
        return result
    except Exception as error:
        sample['outcome'] = type(error).__name__
        raise
    finally:
        sample['seconds'] = round(time.monotonic() - started, 6)
        calls.write(json.dumps(sample) + '\n')
serving.post = observed_post
import types, subprocess
reactive_source = Path('/home/alex/workspace/rupurt/rey/tests/reactive.py').read_text()
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--', 'tests/reactive.py'], cwd='/home/alex/workspace/rupurt/rey')
Path('/var/tmp/transit-lifecycle-reactive-frozen-read.patch').write_bytes(patch)
record['fixture_patch_sha256'] = hashlib.sha256(patch).hexdigest()
reactive = types.ModuleType('reactive')
reactive.__file__ = str(source / 'tests/reactive.py')
sys.modules['reactive'] = reactive
exec(compile(reactive_source, reactive.__file__, 'exec'), reactive.__dict__)
record_path.write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
try:
    serving.run(*binaries, tls=True, reactive=True, reactive_browser=True)
    record['status'] = 'passed'
except Exception as error:
    record.update(status='failed', exception=type(error).__name__)
    raise
finally:
    calls.close()
    record['seconds'] = round(time.monotonic() - started, 2)
    record_path.write_text(json.dumps(record, indent=2) + '\n')
    print('Retained diagnostic fixture:', directory, flush=True)
