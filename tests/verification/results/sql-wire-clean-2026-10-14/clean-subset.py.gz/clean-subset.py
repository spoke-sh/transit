"""Create a pristine committed-source clone for one explicit SDK subset."""
from pathlib import Path
import os
import subprocess
import sys
import tempfile

root = Path('/home/alex/workspace/rupurt/rey')
label, *tasks = sys.argv[1:]
if subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root):
    raise SystemExit('Tracked source changes must be committed first')
revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
directory = Path(tempfile.mkdtemp(prefix='transit-sql-'+label+'-',dir='/var/tmp'))
checkout = directory / 'src'
scratch = directory / 'tmp'
scratch.mkdir()
subprocess.run(['git','clone','--quiet','--local','--no-hardlinks','--no-checkout',str(root),str(checkout)],check=True)
subprocess.run(['git','checkout','--quiet','--detach',revision],cwd=checkout,check=True)
print(f'Clean SDK subset {label}: {revision} in {checkout}',flush=True)
env = {k:v for k,v in os.environ.items() if not k.startswith('REY_') and k not in ('KUBECONFIG','LOG_LEVEL','LOG_FORMAT')}
subprocess.run(['nix','develop','--command','env',f'TMPDIR={scratch}','just','transit-board::install'],cwd=checkout,env=env,check=True)
subprocess.run(['nix','develop','.#bindings','--command','env',f'TMPDIR={scratch}','python3','-B','/tmp/rey-sql-subset-runner.py',str(checkout),*tasks],cwd=checkout,env=env,check=True)
print(f'Clean SDK subset {label} passed; source, selection and timing evidence retained in {checkout}',flush=True)
