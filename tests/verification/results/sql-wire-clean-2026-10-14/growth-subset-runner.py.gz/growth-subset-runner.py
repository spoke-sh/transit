"""Run explicitly selected unchanged inventory tasks in an isolated clean checkout."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

checkout = Path(sys.argv[1])
selected = sys.argv[2:]
spec = importlib.util.spec_from_file_location('transit_ci', checkout / 'tests/ci.py')
ci = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ci)
canonical = ci.LANES['growth']
if not selected or len(selected) != len(set(selected)) or any(task not in canonical for task in selected):
    raise SystemExit('Invalid growth subset')
retained = checkout / '.cache/ci/growth-subset.json'
retained.parent.mkdir(parents=True, exist_ok=True)
retained.write_text(json.dumps({'scope':'explicit subset of the canonical growth lane; not a complete lane', 'canonical_tasks':canonical, 'selected_tasks':selected, 'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2)+'\n')
ci.LANES['growth'] = selected
sys.argv = ['tests/ci.py', 'growth']
ci.main()
