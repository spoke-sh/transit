import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time

source = Path('/var/tmp/transit-ci-hequxq0w/src')
sys.path.insert(0, str(source / 'tests'))
import serving

directory = Path(tempfile.mkdtemp(prefix='transit-reactive-object-io-', dir='/var/tmp'))
record_path = Path('/var/tmp/transit-lifecycle-reactive-object-io.json')
calls = (directory / 'observations.jsonl').open('w', buffering=1)
record = dict(source_revision='717f5579362a1135d0623668faa6a58f3788c6b9',
              source=str(source), fixture=str(directory), status='running',
              method='Unchanged committed fixture and binaries; retain full fixture and time public test-peer observations. No deadline or runtime changes.', binaries=[])
names = [('c46c3d5ea0712c1ea79e4e1222164d51', 'transit-node'),
         ('10e86b3699c0dd1a8172785cde9cee2b', 'transit-serving-example'),
         ('629eeea725bba78fe8137c5177effacc', 'transit-query-host'),
         ('e9d3569cd54eab62c9c32cd108c6be38', 'transit-station-host')]
binaries = []
for key, name in names:
    path = source / '.zig-cache/o' / key / name
    record['binaries'].append(dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    binaries.append(str(path))
runtime_node = Path('/var/tmp/transit-lifecycle-private-object-binaries/transit-node')
binaries[0] = str(runtime_node)
record['binaries'][0] = dict(path=str(runtime_node), sha256=hashlib.sha256(runtime_node.read_bytes()).hexdigest())
record['node_source_revision'] = '5b10004c39972c6f66ab7c35b0b911865073243f'
record['method'] = 'Unchanged 717 fixture and caller binaries; replace only node with committed private-object mutex correction. Retain full physical ext4 fixture. No deadline or protocol changes.'

original_directory = tempfile.TemporaryDirectory
class Retained:
    def __enter__(self):
        return str(directory)
    def __exit__(self, *_):
        return False
def fixture_directory(*args, **kwargs):
    return Retained() if kwargs.get('prefix') == 'transit-serving-' else original_directory(*args, **kwargs)
tempfile.TemporaryDirectory = fixture_directory
original_post = serving.post
def observed_post(port, path, value, *args, **kwargs):
    started = time.monotonic()
    sample = dict(started=started, path=path)
    if 'query' in value:
        sample['action'] = next(iter(value['query']['kind']))
    elif 'request' in value:
        sample['action'] = next(iter(value['request']['command']))
    try:
        result = original_post(port, path, value, *args, **kwargs)
        sample['outcome'] = 'returned'
        if isinstance(result, tuple):
            sample['status'] = result[0]
            if isinstance(result[1], dict):
                sample['stage'] = result[1].get('stage')
        return result
    except Exception as error:
        sample['outcome'] = type(error).__name__
        raise
    finally:
        sample['seconds'] = round(time.monotonic() - started, 6)
        calls.write(json.dumps(sample) + '\n')
serving.post = observed_post
record_path.write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
try:
    serving.run(*binaries, tls=True, reactive=True, reactive_browser=True)
    record['status'] = 'passed'
except Exception as error:
    record.update(status='failed', exception=type(error).__name__)
    raise
finally:
    calls.close()
    record['seconds'] = round(time.monotonic() - started, 2)
    record_path.write_text(json.dumps(record, indent=2) + '\n')
    print('Retained diagnostic fixture:', directory, flush=True)
