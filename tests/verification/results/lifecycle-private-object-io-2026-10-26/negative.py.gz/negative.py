import hashlib,json,subprocess,time
from pathlib import Path
root=Path('/home/alex/workspace/rupurt/rey')
relative='packages/zig/transit-backend-local/src/Backend.zig'
path=root/relative
original=path.read_bytes()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
old=subprocess.check_output(['git','show','25858cb06:'+relative],cwd=root)
record={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'mutation':'Replace only Backend.zig with preceding broad object-I/O mutex implementation; retain new paused-sync regression.','status':'running','original_sha256':hashlib.sha256(original).hexdigest(),'mutation_sha256':hashlib.sha256(old).hexdigest()}
out=Path('/var/tmp/transit-lifecycle-private-object-negative')
Path(str(out)+'.json').write_text(json.dumps(record,indent=2)+'\n')
Path(str(out)+'.original.zig').write_bytes(original)
start=time.monotonic()
try:
    path.write_bytes(old)
    with Path(str(out)+'.log').open('w') as log:
        result=subprocess.run(['nix','develop','--option','eval-cache','false','--command','zig','build','test-local-native','--summary','all'],cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    record['exit_code']=result.returncode
    text=Path(str(out)+'.log').read_text()
    record['expected_regression_failure']=result.returncode!=0 and 'ProgressTimeout' in text and 'paused private object sync' in text
    record['status']='control_failed_as_expected' if record['expected_regression_failure'] else 'unexpected_control_result'
finally:
    path.write_bytes(original)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==record['original_sha256']
    record['source_restored']=True
    record['seconds']=round(time.monotonic()-start,2)
    Path(str(out)+'.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
