import ctypes, hashlib, json, sys, time, urllib.request
from pathlib import Path
source=Path('/var/tmp/transit-ci-7teleeku/src'); sys.path.insert(0,str(source/'tests'))
from server import Fixture
from server_sql import call, wait_status
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
root=Path('/var/tmp/transit-server-proof-mvb4ngof')
f=Fixture.__new__(Fixture); f.root=root; f.cli=str(root/'transit'); f.path=root/'transit.yaml'; f.config=json.loads(f.path.read_text()); f.no_ui=True; f.process=None; f.logs=[p.open('rb') for p in sorted(root.glob('manager-*.stderr'))]; f.activation=None; f.markers=set(); f.reserved_ports=set(); f.http=urllib.request.build_opener(urllib.request.ProxyHandler({})); f.url='http://127.0.0.1:'+str(f.config['ports']['gateway'])
gateway=Path(f.config['executables']['sql_gateway'])
base=Path('/var/tmp/transit-lifecycle-delete-drop-observation')
artifacts=[root/'transit',*(Path(x) for x in f.config['executables'].values())]
r={'revision':'e550f4ed54ec4cd9a1c40cb4c568a64752861a16','installation':str(root),'started':time.time(),'complete':False,'actions':['restart the original retained installation with unchanged binaries/configuration','list and inspect original local-account operations through signed control','no SQL resubmission, execution, cancellation or operation replacement'],'artifacts':{p.name:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in artifacts},'pages':[],'statuses':[]}
def save(): base.with_suffix('.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 f.start(); f.ready(timeout=300); wait_status(f,lambda s:s['service']['state']=='accepting' and all(a['initialized'] for a in s['accounts']))
 control=f.installation/'sql/accounts/local/control.json'
 cursor=None
 for _ in range(100):
  args=[gateway,'control',control,'list']
  if cursor is not None:
   cursor_path=base.with_name(base.name+'-cursor.json'); cursor_path.write_text(json.dumps(cursor)); args.append(cursor_path)
  page=json.loads(call(args,timeout=120,retry_observation=True)); r['pages'].append(page); save()
  cursor=page['next']
  if cursor is None: break
 else: raise AssertionError('Observed operation-page bound exceeded')
 for page in r['pages']:
  for entry in page['entries']:
   r['statuses'].append(json.loads(call([gateway,'control',control,'status',str(entry['operation'])],timeout=120,retry_observation=True))); save()
 r['complete']=True
except BaseException as e: r['failure']=repr(e); raise
finally:
 f.cleanup(); r['finished']=time.time(); save()
 print(json.dumps({'complete':r['complete'],'failure':r.get('failure'),'operations':[{'operation':x['operation'],'has_terminal':x['terminal'] is not None} for x in r['statuses']]},indent=2),flush=True)
