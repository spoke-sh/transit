import hashlib,json,sys,time
from pathlib import Path
source=Path('/var/tmp/transit-ci-7teleeku/src');sys.path.insert(0,str(source/'tests'))
import server_direct_tables as proof
original_root=Path('/var/tmp/transit-server-proof-mvb4ngof'); config=json.loads((original_root/'transit.yaml').read_text())
artifacts=[original_root/'transit',*(Path(config['executables'][key]) for key in ['node','query_host','board','sql_gateway'])]
base=Path('/var/tmp/transit-lifecycle-direct-tables-diagnostic'); capture=Path(str(base)+'-stderr');capture.mkdir(exist_ok=True)
r={'revision':'e550f4ed54ec4cd9a1c40cb4c568a64752861a16','started':time.time(),'complete':False,'method':'Fresh exact full installed Table lifecycle workload with same compiled binary bytes, explicit node/gateway exec wrappers retaining stderr. Artifact paths and wrapper hashes differ; diagnostic only, not installed adjacency qualification. No SQL resubmission into original failed installation; no workload/assertion/deadline changes.','artifacts':{p.name:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in artifacts},'captures':[],'installations':[]}
def save():base.with_suffix('.json').write_text(json.dumps(r,indent=2)+'\n')
original_init=proof.LifecycleFixture.__init__
def diagnostic_init(fixture,*args,**kwargs):
 original_init(fixture,*args,**kwargs)
 for role in ['node','sql_gateway']:
  executable=fixture.config['executables'][role]; wrapper=fixture.root/(role+'-diagnostic'); log=capture/(fixture.root.name+'-'+role+'.stderr')
  code='#!'+sys.executable+'\nimport os,sys\nfd=os.open('+repr(str(log))+',os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)\nos.dup2(fd,2)\nos.close(fd)\nos.execv('+repr(executable)+',['+repr(executable)+',*sys.argv[1:]])\n'
  wrapper.write_text(code);wrapper.chmod(0o700);fixture.config['executables'][role]=str(wrapper);r['captures'].append(str(log))
 fixture.path.write_text(json.dumps(fixture.config));r['installations'].append(str(fixture.root));save()
proof.LifecycleFixture.__init__=diagnostic_init
save()
try:
 proof.run(*map(str,artifacts));r['complete']=True
except BaseException as e:r['failure']=repr(e);raise
finally:
 r['finished']=time.time();r['capture_hashes']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in capture.glob('*.stderr')};save();print(json.dumps({k:r[k] for k in ['complete','failure','started','finished'] if k in r}),flush=True)
