import json,os,platform,subprocess,time
from pathlib import Path
root=Path.cwd()
suite=json.loads((root/'tests/verification/suite.json').read_text())
selected=[('growth',task) for task in suite['lanes']['growth'][:15]]+[('experience',task) for task in suite['lanes']['experience']]
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert revision=='9dffe9e4e15d5da132d9e2a0b0f8b8815d3af729'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
assert len(selected)==22
out=root/'.cache/ci/configuration-final-scope.json'
out.parent.mkdir(parents=True,exist_ok=True)
started=time.monotonic()
results=[]
metadata=dict(version=1,revision=revision,profile='configuration-clean-final-revision',expected_tasks=[task for _,task in selected],completed=False,active_task=None,machine=dict(platform=platform.platform(),logical_cpus=os.cpu_count()))
def checkpoint():
    metadata.update(result_count=len(results),seconds=round(time.monotonic()-started,2),checkpoint_unix=time.time())
    for path,value in ((out,results),(out.with_suffix('.meta.json'),metadata)):
        temp=path.with_suffix('.tmp')
        temp.write_text(json.dumps(value,indent=2)+'\n')
        temp.replace(path)
checkpoint()
try:
    for lane,task in selected:
        print(f'Clean continuation {lane}: just {task}',flush=True)
        metadata['active_task']=dict(lane=lane,task=task)
        checkpoint()
        start=time.monotonic()
        code=130
        try:
            code=subprocess.run(['just',task]).returncode
        finally:
            results.append(dict(lane=lane,task=task,seconds=round(time.monotonic()-start,2),exit_code=code))
            metadata['active_task']=None
            checkpoint()
        if code:
            raise SystemExit(code)
    metadata['completed']=True
finally:
    checkpoint()
