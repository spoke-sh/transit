import json,os,platform,subprocess,sys,time
from pathlib import Path
root=Path.cwd();label=sys.argv[1]
suite=json.loads((root/'tests/verification/suite.json').read_text())
tasks={'c':['bindings::c-sdk-test'],'java':['bindings::java-sdk-test'],'dotnet':['bindings::dotnet-sdk-test'],'node':['bindings::node-sdk-test','bindings::logical-test'],'rust':['bindings::rust-sdk-test'],'ruby':['bindings::ruby-sdk-test'],'beam':['bindings::beam-sdk-test']}[label]
selected=[(next(lane for lane in ('bindings-1','bindings-2') if task in suite['lanes'][lane]),task) for task in tasks]
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert revision=='9dffe9e4e15d5da132d9e2a0b0f8b8815d3af729'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
out=root/f'.cache/ci/configuration-{label}.json';out.parent.mkdir(parents=True,exist_ok=True)
started=time.monotonic();results=[]
metadata=dict(version=1,revision=revision,profile='configuration-clean-retry',expected_tasks=tasks,completed=False,active_task=None,machine=dict(platform=platform.platform(),logical_cpus=os.cpu_count()),fixture_policy='Full canonical recipes create fresh disposable fixtures; only outputs built in this source-only clean checkout are reused.')
def checkpoint():
    metadata.update(result_count=len(results),seconds=round(time.monotonic()-started,2),checkpoint_unix=time.time())
    for path,value in ((out,results),(out.with_suffix('.meta.json'),metadata)):
        temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)
checkpoint()
try:
    for lane,task in selected:
        metadata['active_task']=dict(lane=lane,task=task);checkpoint()
        print(f'Clean retry {lane}: just {task}',flush=True)
        code=130;start=time.monotonic()
        try:code=subprocess.run(['just',task]).returncode
        finally:
            results.append(dict(lane=lane,task=task,seconds=round(time.monotonic()-start,2),exit_code=code))
            metadata['active_task']=None;checkpoint()
        if code:raise SystemExit(code)
    metadata['completed']=True
finally:checkpoint()
