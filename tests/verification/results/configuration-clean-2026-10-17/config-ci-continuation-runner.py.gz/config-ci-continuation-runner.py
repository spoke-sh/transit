import json,os,platform,subprocess,time
from pathlib import Path
root=Path.cwd()
suite=json.loads((root/'tests/verification/suite.json').read_text())
all_tasks=[(lane,task) for lane in suite['tiers']['ordinary'] for task in suite['lanes'][lane]]
prefix=json.loads(Path('/tmp/config-ci-448-prefix-evidence/all.json').read_text())
assert len(prefix)==43 and all(x['exit_code']==0 for x in prefix)
assert [(x['lane'],x['task']) for x in prefix]==all_tasks[:43]
selected=[(lane,task) for lane,task in all_tasks[43:] if lane!='experience']
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changes=subprocess.check_output(['git','diff','--name-only','44806186d6de8837c7ea34db5a61bdab1509c67b',revision],text=True).splitlines()
assert set(changes)<=set(('tests/sql_wire/gateway.py','tests/sql_wire/lifecycle.py','tests/README.md','packages/zig/transit-config/src/Input.zig','tests/cli_diagnostics.py','docs/reference/configuration.md')),changes
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
assert len(selected)==38
out=root/'.cache/ci/configuration-continuation.json'
out.parent.mkdir(parents=True,exist_ok=True)
started=time.monotonic()
results=[]
metadata=dict(version=1,revision=revision,profile='configuration-clean-continuation',expected_tasks=[task for _,task in selected],prefix_revision='44806186d6de8837c7ea34db5a61bdab1509c67b',prefix_tasks=43,separate_lanes=['core','experience'],changes_after_prefix=changes,completed=False,active_task=None,machine=dict(platform=platform.platform(),logical_cpus=os.cpu_count()))
def checkpoint():
    metadata.update(result_count=len(results),seconds=round(time.monotonic()-started,2),checkpoint_unix=time.time())
    for path,value in ((out,results),(out.with_suffix('.meta.json'),metadata)):
        temp=path.with_suffix('.tmp')
        temp.write_text(json.dumps(value,indent=2)+'\n')
        temp.replace(path)
checkpoint()
try:
    for lane,task in selected:
        print(f'Clean continuation {lane}: just {task}',flush=True)
        metadata['active_task']=dict(lane=lane,task=task)
        checkpoint()
        start=time.monotonic()
        code=130
        try:
            code=subprocess.run(['just',task]).returncode
        finally:
            results.append(dict(lane=lane,task=task,seconds=round(time.monotonic()-start,2),exit_code=code))
            metadata['active_task']=None
            checkpoint()
        if code:
            raise SystemExit(code)
    metadata['completed']=True
finally:
    checkpoint()
