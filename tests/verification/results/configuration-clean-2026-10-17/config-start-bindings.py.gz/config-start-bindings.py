from pathlib import Path
import json,subprocess,time
work=Path('/var/tmp/transit-config-head-d76m3lx6')
evidence=work/'.cache/ci/clean/9dffe9e4e15d-transit-ci-wgw5ihud'
while not (evidence/'core.meta.json').exists() or Path('/var/tmp/transit-ci-wgw5ihud').exists():
    time.sleep(2)
meta=json.loads((evidence/'core.meta.json').read_text())
rows=json.loads((evidence/'core.json').read_text())
assert meta['completed'] and len(rows)==28 and all(row['exit_code']==0 for row in rows)
assert meta['revision']=='9dffe9e4e15d5da132d9e2a0b0f8b8815d3af729'
Path('/tmp/config-ci-bindings-started.json').write_text(json.dumps(dict(revision=meta['revision'],unix=time.time())))
raise SystemExit(subprocess.run(['nix','develop','--command','just','ci-clean','--lane','bindings'],cwd=work).returncode)
