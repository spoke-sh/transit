import json,os,signal,time,shutil
from pathlib import Path
root=Path('/var/tmp/transit-ci-oaln99xm/src')
meta=root/'.cache/ci/bindings-2.meta.json'
while meta.exists():
    value=json.loads(meta.read_text())
    rows=json.loads(meta.with_name('bindings-2.json').read_text())
    if any(row['exit_code']!=0 for row in rows):
        raise SystemExit('Bindings failed; no interruption performed.')
    if value['result_count']>=1:
        assert value['result_count']==1
        assert all(row['lane']=='bindings-2' and row['task']=='bindings::c-sdk-test' for row in rows)
        evidence=Path('/tmp/config-ci-c-evidence')
        evidence.mkdir(exist_ok=True)
        for name in ('bindings-2.json','bindings-2.meta.json'):
            shutil.copy2(root/'.cache/ci'/name,evidence/name)
        (evidence/'interruption.json').write_text(json.dumps(dict(reason='The canonical C/C++ SDK task passed. Stop before duplicate Java/.NET/BEAM work: those recipes run independently in fresh clean checkouts at the same revision. The enclosing four-task bindings-2 run remains incomplete.',revision=value['revision'],active=value.get('active_task'),completed=value['result_count'],process_group=1536255,unix=time.time()),indent=2)+'\n')
        assert Path('/proc/1539678/cwd').resolve()==root
        os.killpg(1536255,signal.SIGINT)
        print('C/C++ prefix complete; independent Java/.NET/BEAM runs own the remaining tasks.',flush=True)
        break
    time.sleep(.5)
