import json,os,shutil,subprocess,sys
from pathlib import Path
label=sys.argv[1]
if label=='node':
    root=Path('/var/tmp/transit-ci-zmhrkfw2/src')
    Path('/tmp/config-ci-node-location.json').write_text(json.dumps(dict(root=str(root.parent),checkout=str(root),revision='9dffe9e4e15d5da132d9e2a0b0f8b8815d3af729')))
else:root=Path(json.loads(Path(f'/tmp/config-ci-{label}-location.json').read_text())['checkout'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='9dffe9e4e15d5da132d9e2a0b0f8b8815d3af729'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
env={k:v for k,v in os.environ.items() if not k.startswith('REY_') and k not in ('KUBECONFIG','LOG_LEVEL','LOG_FORMAT')}
env['NIX_CONFIG']=env.get('NIX_CONFIG','')+'\neval-cache = false\n'
subprocess.run(['nix','develop','.#bindings','--command','env',f'TMPDIR={root.parent}/tmp','python3','-B','/tmp/config-sdk-retry-runner.py',label],cwd=root,env=env,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
shutil.copytree(root/'.cache/ci',f'/tmp/config-ci-{label}-evidence')
shutil.rmtree(root.parent)
print(f'Clean {label} canonical retry scope passed.',flush=True)
