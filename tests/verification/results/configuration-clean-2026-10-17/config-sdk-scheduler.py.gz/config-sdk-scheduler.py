import json,subprocess,sys,time
from pathlib import Path
pending=['node','beam','c','java','dotnet','rust','ruby']
active={};finished=[];failed=False
started=time.time()
while pending or active:
    limit=2 if Path('/tmp/config-ci-continuation-evidence/configuration-continuation.json').exists() else 1
    while pending and len(active)<limit and not failed:
        label=pending.pop(0)
        log=Path(f'/tmp/config-ci-{label}-final.log').open('w')
        process=subprocess.Popen([sys.executable,'-B','/tmp/config-sdk-retry.py',label],stdout=log,stderr=subprocess.STDOUT)
        active[label]=(process,log,time.time())
        print(f'Started complete {label} canonical retry; active limit {limit}.',flush=True)
    for label,(process,log,since) in list(active.items()):
        code=process.poll()
        if code is None:continue
        log.close();del active[label]
        finished.append(dict(label=label,exit_code=code,seconds=round(time.time()-since,2)))
        print(f'{label}: exit {code}; {finished[-1]["seconds"]}s',flush=True)
        if code:failed=True
    state=dict(started_unix=started,updated_unix=time.time(),pending=pending,active=list(active),finished=finished,failed=failed)
    Path('/tmp/config-sdk-scheduler-state.json').write_text(json.dumps(state,indent=2)+'\n')
    if failed and not active:raise SystemExit(1)
    time.sleep(.5)
assert len(finished)==7 and all(x['exit_code']==0 for x in finished)
while not Path('/tmp/config-ci-continuation-evidence/configuration-continuation.json').exists():time.sleep(.5)
Path('/tmp/config-sdk-retries-complete.json').write_text(json.dumps(state,indent=2)+'\n')
print('All complete SDK retry scopes passed; shared/model tail may start.',flush=True)
