import json,os,signal,time,shutil
from pathlib import Path
root=Path('/var/tmp/transit-config-continuation-8m0yf685/src')
meta=root/'.cache/ci/configuration-continuation.meta.json'
while meta.exists():
    value=json.loads(meta.read_text())
    rows=json.loads(meta.with_name('configuration-continuation.json').read_text())
    if any(row['exit_code']!=0 for row in rows):
        raise SystemExit('Continuation failed; no interruption performed.')
    if value['result_count']>=19 and Path('/tmp/config-ci-bindings-started.json').exists():
        assert value['result_count']==19
        assert all(row['lane'] in ('growth','launchers') for row in rows)
        evidence=Path('/tmp/config-ci-continuation-evidence')
        evidence.mkdir(exist_ok=True)
        for name in ('configuration-continuation.json','configuration-continuation.meta.json'):
            shutil.copy2(root/'.cache/ci'/name,evidence/name)
        (evidence/'interruption.json').write_text(json.dumps(dict(reason='All 17 remaining growth recipes and both launcher recipes passed. Stop before duplicate bindings work: all 19 bindings recipes run in separate clean scopes at the same revision. This enclosing continuation remains incomplete.',revision=value['revision'],active=value.get('active_task'),completed=value['result_count'],process_group=535264,unix=time.time()),indent=2)+'\n')
        assert Path('/proc/539022/cwd').resolve()==root
        os.killpg(535264,signal.SIGINT)
        print('Continuation prefix complete; independent bindings scopes own remaining tasks.',flush=True)
        break
    time.sleep(.5)
