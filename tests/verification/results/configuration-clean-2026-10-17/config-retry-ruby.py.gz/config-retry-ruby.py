import os,subprocess,shutil
from pathlib import Path
root=Path('/var/tmp/transit-config-ruby-iqvrl7zn/src')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='9dffe9e4e15d5da132d9e2a0b0f8b8815d3af729'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
env={k:v for k,v in os.environ.items() if not k.startswith('REY_') and k not in ('KUBECONFIG','LOG_LEVEL','LOG_FORMAT')}
env['NIX_CONFIG']=env.get('NIX_CONFIG','')+'\neval-cache = false\n'
subprocess.run(['nix','develop','.#bindings','--command','env',f'TMPDIR={root.parent}/tmp','python3','-B','/tmp/config-ci-task-runner.py','ruby','bindings::ruby-sdk-test'],cwd=root,env=env,check=True)
shutil.copytree(root/'.cache/ci','/tmp/config-ci-ruby-evidence')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
shutil.rmtree(root.parent)
print('Clean Ruby canonical task passed on fresh fixtures after recorded setup-timeout failure.',flush=True)
