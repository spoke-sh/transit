import json,os,signal,time,shutil
from pathlib import Path
root=Path('/var/tmp/transit-ci-zmhrkfw2/src')
meta=root/'.cache/ci/bindings.meta.json'
while meta.exists():
    value=json.loads(meta.read_text())
    rows=json.loads(meta.with_name('bindings.json').read_text())
    if any(row['exit_code']!=0 for row in rows):
        raise SystemExit('Bindings failed; no interruption performed.')
    if value['result_count']>=5:
        assert value['result_count']==5
        assert all(row['lane']=='bindings-1' for row in rows)
        evidence=Path('/tmp/config-ci-bindings1-evidence')
        evidence.mkdir(exist_ok=True)
        for name in ('bindings.json','bindings.meta.json'):
            shutil.copy2(root/'.cache/ci'/name,evidence/name)
        (evidence/'interruption.json').write_text(json.dumps(dict(reason='The first five canonical bindings-1 recipes passed (contract/native/Python/Node/logical values). Stop before duplicate Rust/Ruby work: those recipes run independently in fresh clean checkouts at the same revision. The remaining eight canonical shared/model recipes run in a separate clean continuation. The enclosing combined bindings run remains incomplete.',revision=value['revision'],active=value.get('active_task'),completed=value['result_count'],process_group=1113674,unix=time.time()),indent=2)+'\n')
        assert Path('/proc/1116907/cwd').resolve()==root
        os.killpg(1113674,signal.SIGINT)
        print('Five-task bindings prefix complete; independent language and shared-tail scopes own remaining tasks.',flush=True)
        break
    time.sleep(.5)
