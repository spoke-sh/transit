import json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
root=Path('/home/alex/workspace/rupurt/rey')
label='tail'
task='bindings-1 shared/model continuation'
while not Path('/tmp/config-sdk-retries-complete.json').exists():time.sleep(.5)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert revision=='9dffe9e4e15d5da132d9e2a0b0f8b8815d3af729'
work=Path(tempfile.mkdtemp(prefix=f'transit-config-{label}-',dir='/var/tmp'))
checkout=work/'src';scratch=work/'tmp';scratch.mkdir()
Path(f'/tmp/config-ci-{label}-location.json').write_text(json.dumps(dict(root=str(work),checkout=str(checkout),revision=revision,task=task)))
def run(args,**kwargs):return subprocess.run(args,cwd=checkout,check=True,**kwargs)
subprocess.run(['git','clone','--quiet','--local','--no-hardlinks','--no-checkout',str(root),str(checkout)],check=True)
run(['git','checkout','--quiet','--detach',revision])
print(f'Clean canonical task {task}: {revision} in {checkout}',flush=True)
env={k:v for k,v in os.environ.items() if not k.startswith('REY_') and k not in ('KUBECONFIG','LOG_LEVEL','LOG_FORMAT')}
env['NIX_CONFIG']=env.get('NIX_CONFIG','')+'\neval-cache = false\n'
run(['nix','develop','--command','env',f'TMPDIR={scratch}','just','transit-board::install'],env=env)
run(['nix','develop','.#bindings','--command','env',f'TMPDIR={scratch}','python3','-B','/tmp/config-ci-tail-runner.py'],env=env)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=checkout,text=True)
evidence=Path(f'/tmp/config-ci-{label}-evidence')
shutil.copytree(checkout/'.cache/ci',evidence)
shutil.rmtree(work)
print(f'Clean canonical task {task} passed; evidence {evidence}',flush=True)
