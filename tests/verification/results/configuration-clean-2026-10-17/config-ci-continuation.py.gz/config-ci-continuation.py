from pathlib import Path
import json,os,shutil,subprocess,tempfile
root=Path('/home/alex/workspace/rupurt/rey')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
work=Path(tempfile.mkdtemp(prefix='transit-config-continuation-',dir='/var/tmp'))
checkout=work/'src'
scratch=work/'tmp';scratch.mkdir()
Path('/tmp/config-ci-continuation-location.json').write_text(json.dumps(dict(root=str(work),checkout=str(checkout),revision=revision)))
def run(args,**kw):
    subprocess.run(args,cwd=checkout,check=True,**kw)
subprocess.run(['git','clone','--quiet','--local','--no-hardlinks','--no-checkout',str(root),str(checkout)],check=True)
run(['git','checkout','--quiet','--detach',revision])
print(f'Clean continuation at {revision} in {checkout}',flush=True)
env={k:v for k,v in os.environ.items() if not k.startswith('REY_') and k not in ('KUBECONFIG','LOG_LEVEL','LOG_FORMAT')}
run(['nix','develop','--command','env',f'TMPDIR={scratch}','just','transit-board::install'],env=env)
run(['nix','develop','.#bindings','--command','env',f'TMPDIR={scratch}','python3','-B','/tmp/config-ci-continuation-runner.py'],env=env)
evidence=Path('/tmp/config-ci-continuation-evidence')
shutil.copytree(checkout/'.cache/ci',evidence)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=checkout,text=True)
shutil.rmtree(work)
print(f'Clean continuation passed all 38 selected canonical tasks; evidence {evidence}',flush=True)
