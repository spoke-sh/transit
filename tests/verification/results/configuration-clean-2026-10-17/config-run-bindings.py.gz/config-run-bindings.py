import os,subprocess
from pathlib import Path
env=os.environ.copy()
env['NIX_CONFIG']=env.get('NIX_CONFIG','')+'\neval-cache = false\n'
raise SystemExit(subprocess.run(['nix','develop','--command','just','ci-clean','--lane','bindings'],cwd=Path('/var/tmp/transit-config-head-d76m3lx6'),env=env).returncode)
