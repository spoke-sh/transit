import subprocess,sys,time
from pathlib import Path
queue=sys.argv[1]
gates=[Path('/tmp/config-ci-c-evidence/bindings-2.json'),Path('/tmp/config-ci-java-evidence/configuration-java.meta.json'),Path('/tmp/config-ci-dotnet-evidence/configuration-dotnet.meta.json')]
if queue=='b':gates.append(Path('/tmp/config-ci-continuation-evidence/configuration-continuation.json'))
while not all(p.exists() for p in gates):time.sleep(.5)
for label in (('beam','ruby') if queue=='a' else ('node','rust')):
    print(f'Lower-concurrency queue {queue}: {label}',flush=True)
    with Path(f'/tmp/config-ci-{label}-final.log').open('w') as log:
        subprocess.run(['python3','-B','/tmp/config-sdk-retry.py',label],stdout=log,stderr=subprocess.STDOUT,check=True)
print(f'Queue {queue} completed.',flush=True)
