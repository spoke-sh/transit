import json,os,platform,subprocess,sys,time
from pathlib import Path
root=Path.cwd()
label,task=sys.argv[1:]
suite=json.loads((root/'tests/verification/suite.json').read_text())
lane=next(name for name in ('bindings-1','bindings-2') if task in suite['lanes'][name])
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert revision=='9dffe9e4e15d5da132d9e2a0b0f8b8815d3af729'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
out=root/f'.cache/ci/configuration-{label}.json';out.parent.mkdir(parents=True,exist_ok=True)
started=time.monotonic();results=[]
metadata=dict(version=1,revision=revision,profile='configuration-clean-canonical-task',expected_tasks=[task],canonical_lane=lane,canonical_lane_inventory=suite['lanes'][lane],completed=False,active_task=None,machine=dict(platform=platform.platform(),logical_cpus=os.cpu_count()))
def checkpoint():
    metadata.update(result_count=len(results),seconds=round(time.monotonic()-started,2),checkpoint_unix=time.time())
    for path,value in ((out,results),(out.with_suffix('.meta.json'),metadata)):
        temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)
checkpoint()
try:
    metadata['active_task']=dict(lane=lane,task=task);checkpoint()
    print(f'Canonical {lane} task: just {task}',flush=True)
    code=130
    try:code=subprocess.run(['just',task]).returncode
    finally:
        results.append(dict(lane=lane,task=task,seconds=round(time.monotonic()-started,2),exit_code=code))
        metadata['active_task']=None;checkpoint()
    if code:raise SystemExit(code)
    metadata['completed']=True
finally:checkpoint()
