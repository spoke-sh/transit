# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: query.spec.ts >> one explicit query survives Canvas/Browse changes and is cleared on revocation
- Location: browser/query.spec.ts:5:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByLabel('Resource participation')
Expected substring: "One selected PID."
Received string:    "Shared-resource participationThe source or observation cut changed while reading. Start a fresh observation; pages from the earlier and new cuts cannot be combined. conflict · inspection.observation_changed Outcome: not applicable; evidence: none. operation: \"Board inspection\" completion: false Refresh the current observation.At most eight processes and eight associations per process. Each page has its own basis; counts do not measure traffic or a complete realm.Refresh participationAssociation and resource observations are independent of Atlas. Association does not confer ownership, permission or readiness."
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByLabel('Resource participation') with timeout 5000ms
  - waiting for getByLabel('Resource participation')
    2 × locator resolved to <section class="participation" aria-label="Resource participation">…</section>
      - unexpected value "Shared-resource participationReading authorized associations…At most eight processes and eight associations per process. Each page has its own basis; counts do not measure traffic or a complete realm.Refresh participationAssociation and resource observations are independent of Atlas. Association does not confer ownership, permission or readiness."
    12 × locator resolved to <section class="participation" aria-label="Resource participation">…</section>
       - unexpected value "Shared-resource participationThe source or observation cut changed while reading. Start a fresh observation; pages from the earlier and new cuts cannot be combined. conflict · inspection.observation_changed Outcome: not applicable; evidence: none. operation: "Board inspection" completion: false Refresh the current observation.At most eight processes and eight associations per process. Each page has its own basis; counts do not measure traffic or a complete realm.Refresh participationAssociation and resource observations are independent of Atlas. Association does not confer ownership, permission or readiness."

```

```yaml
- region "Resource participation":
  - heading "Shared-resource participation" [level=3]
  - status: "The source or observation cut changed while reading. Start a fresh observation; pages from the earlier and new cuts cannot be combined. conflict · inspection.observation_changed Outcome: not applicable; evidence: none. operation: \"Board inspection\" completion: false Refresh the current observation."
  - paragraph: At most eight processes and eight associations per process. Each page has its own basis; counts do not measure traffic or a complete realm.
  - button "Refresh participation"
  - paragraph: Association and resource observations are independent of Atlas. Association does not confer ownership, permission or readiness.
```

# Test source

```ts
  1   | import AxeBuilder from "@axe-core/playwright";
  2   | import { test, expect } from "@playwright/test";
  3   | import { execFileSync } from "node:child_process";
  4   | 
  5   | test("one explicit query survives Canvas/Browse changes and is cleared on revocation", async ({
  6   |   page,
  7   |   context,
  8   | }) => {
  9   |   test.setTimeout(180000);
  10  |   page.setDefaultTimeout(15000);
  11  |   const errors: string[] = [];
  12  |   page.on("pageerror", (error) => errors.push(error.message));
  13  |   let submissions = 0;
  14  |   let pageReads = 0;
  15  |   page.on("request", (request) => {
  16  |     if (request.url().endsWith("/api/v1/query") && request.method() === "POST") {
  17  |       const body = request.postDataJSON() as Record<string, unknown>;
  18  |       if ("submit" in body) submissions++;
  19  |       if ("page" in body) pageReads++;
  20  |     }
  21  |   });
  22  |   await page.goto("/");
  23  |   await expect(page.getByRole("heading", { name: "Relief atlas", exact: true })).toBeVisible();
  24  |   await page
  25  |     .getByRole("button", {
  26  |       name: `Select resource ${process.env.BOARD_QUERY_RESOURCE}`,
  27  |       exact: true,
  28  |     })
  29  |     .click();
  30  |   await expect(page.getByRole("button", { name: "Enter resource" })).toBeVisible();
  31  |   await page
  32  |     .getByLabel("Search this authorized page")
  33  |     .fill(`resource ${process.env.BOARD_QUERY_RESOURCE}`);
  34  |   await expect(page.locator(".atlas-evidence")).toContainText("0 processes and 1 resources match");
  35  |   await page.getByLabel("Search this authorized page").fill("");
  36  |   await page.getByRole("button", { name: "Inspect participation", exact: true }).click();
  37  |   await expect(
  38  |     page.getByRole("table", {
  39  |       name: `Authorized associations to resource ${process.env.BOARD_QUERY_RESOURCE}`,
  40  |     }),
  41  |   ).toBeVisible({ timeout: 15000 });
  42  |   await expect(page.getByRole("button", { name: /^Next associations for PID/ })).toBeVisible();
  43  |   await page.getByRole("button", { name: /^Next associations for PID/ }).click();
> 44  |   await expect(page.getByLabel("Resource participation")).toContainText("One selected PID.");
      |                                                           ^ Error: expect(locator).toContainText(expected) failed
  45  |   execFileSync(process.env.BOARD_QUERY_PROOF!, [
  46  |     process.env.BOARD_QUERY_AUTHORITY!,
  47  |     "revoke-inspector-resource",
  48  |     process.env.BOARD_QUERY_CONFIG!,
  49  |   ]);
  50  |   await expect(page.getByLabel("Resource participation")).toHaveCount(0, { timeout: 15000 });
  51  |   execFileSync(process.env.BOARD_QUERY_PROOF!, [
  52  |     process.env.BOARD_QUERY_AUTHORITY!,
  53  |     "restore-inspector-resource",
  54  |     process.env.BOARD_QUERY_CONFIG!,
  55  |   ]);
  56  |   await page.getByRole("button", { name: "Refresh observation", exact: true }).click();
  57  |   await expect(page.getByLabel("Resource participation")).toBeVisible({ timeout: 15000 });
  58  |   for (const density of ["comfortable", "compact"]) {
  59  |     await page.getByLabel("Preview density").selectOption(density);
  60  |     expect(
  61  |       (await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa"]).analyze()).violations,
  62  |     ).toEqual([]);
  63  |   }
  64  |   await page.getByRole("button", { name: "Resources", exact: true }).click();
  65  |   await page.getByLabel("Detail zoom").focus();
  66  |   await page.getByLabel("Detail zoom").press("End");
  67  |   await expect(page.getByLabel("Detail zoom")).toHaveValue("3");
  68  |   await page.screenshot({
  69  |     path: process.env.BOARD_QUERY_SCREENSHOT?.replace(".png", "-atlas.png"),
  70  |     fullPage: true,
  71  |   });
  72  |   await page.getByRole("button", { name: "Enter resource" }).click();
  73  |   const draft = page.getByLabel("SQL draft", { exact: true });
  74  |   await expect(draft).toBeVisible();
  75  |   const sql = "SELECT value FROM items WHERE value = 9007199254740994 LIMIT 1";
  76  |   await draft.fill(sql);
  77  |   await page.getByRole("button", { name: "Browse", exact: true }).click();
  78  |   await expect(draft).toHaveValue(sql);
  79  |   await page.getByRole("button", { name: "Canvas", exact: true }).click();
  80  |   expect(submissions).toBe(0);
  81  |   let dropped = false;
  82  |   const frozen: string[] = [];
  83  |   await page.route("**/api/v1/query", async (route) => {
  84  |     const body = route.request().postDataJSON();
  85  |     if (body.submit) {
  86  |       frozen.push(JSON.stringify(body));
  87  |       if (!dropped) {
  88  |         dropped = true;
  89  |         await route.fetch();
  90  |         await route.abort("failed");
  91  |         return;
  92  |       }
  93  |     }
  94  |     await route.continue();
  95  |   });
  96  |   await page.getByRole("button", { name: "Run query", exact: true }).click();
  97  |   await expect(
  98  |     page.getByRole("button", { name: "Retry exact submission", exact: true }),
  99  |   ).toBeVisible();
  100 |   await page.getByRole("link", { name: "Activity", exact: true }).click();
  101 |   await expect(page.getByRole("heading", { name: "Activity", exact: true })).toBeVisible();
  102 |   await page.getByRole("link", { name: "Atlas", exact: true }).click();
  103 |   await page
  104 |     .getByRole("button", {
  105 |       name: `Select resource ${process.env.BOARD_QUERY_RESOURCE}`,
  106 |       exact: true,
  107 |     })
  108 |     .click();
  109 |   await page.getByRole("button", { name: "Enter resource", exact: true }).click();
  110 |   await expect(
  111 |     page.getByRole("button", { name: "Retry exact submission", exact: true }),
  112 |   ).toBeVisible();
  113 |   await page.getByRole("button", { name: "Retry exact submission", exact: true }).click();
  114 |   expect(frozen[0]).toEqual(frozen[1]);
  115 |   await expect(page.getByLabel("Verified query result")).toBeVisible({ timeout: 120000 });
  116 |   await expect(
  117 |     page.getByLabel("Verified query result").getByText("9007199254740994", { exact: true }),
  118 |   ).toBeVisible();
  119 |   await page.getByRole("button", { name: "Browse", exact: true }).click();
  120 |   await expect(draft).toHaveValue(sql);
  121 |   await expect(page.getByRole("cell", { name: "9007199254740994", exact: true })).toBeVisible();
  122 |   const completed = submissions;
  123 |   expect(completed).toBeGreaterThan(2); // finite upload has several committed steps
  124 |   await draft.fill("SELECT id FROM items LIMIT 2");
  125 |   await page.getByRole("button", { name: "Canvas", exact: true }).click();
  126 |   await expect(draft).toHaveValue("SELECT id FROM items LIMIT 2");
  127 |   await expect(
  128 |     page.getByText("Draft changed. The displayed result belongs to the earlier submitted SQL."),
  129 |   ).toBeVisible();
  130 |   expect(submissions).toBe(completed);
  131 |   const recovery = page.getByLabel("Retained query recovery", { exact: true });
  132 |   const reference = await recovery.innerText();
  133 |   const correlation = /Retained query (\d+)\./.exec(reference)?.[1];
  134 |   expect(correlation).toBeTruthy();
  135 |   const download = page.waitForEvent("download");
  136 |   await page.getByRole("button", { name: "Save reference and use current binding" }).click();
  137 |   expect((await download).suggestedFilename()).toBe("transit-query-reference.json");
  138 |   await expect(page.getByLabel("Verified query result")).toHaveCount(0);
  139 |   await expect(page.getByRole("button", { name: "Run query", exact: true })).toBeEnabled();
  140 |   await page.getByLabel("Existing query namespace", { exact: true }).fill(correlation!);
  141 |   await page.getByRole("button", { name: "Resume without rerunning", exact: true }).click();
  142 |   await expect(page.getByLabel("Verified query result")).toBeVisible();
  143 |   expect(submissions).toBe(completed);
  144 |   await page.screenshot({ path: process.env.BOARD_QUERY_SCREENSHOT, fullPage: true });
```