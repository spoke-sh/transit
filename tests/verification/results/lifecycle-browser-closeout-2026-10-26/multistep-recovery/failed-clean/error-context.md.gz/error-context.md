# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: query.spec.ts >> one explicit query survives Canvas/Browse changes and is cleared on revocation
- Location: browser/query.spec.ts:5:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByLabel('Verified query result')
Expected: visible
Timeout: 120000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByLabel('Verified query result') with timeout 120000ms
  - waiting for getByLabel('Verified query result')

```

```yaml
- banner:
  - link "Transit Board home":
    - /url: /?status=all&sort=pid
    - text: Transit BOARD
  - navigation "Area":
    - button "Workspace" [pressed]
    - button "Operations"
  - text: Realm 45
- complementary "Workspace navigation":
  - paragraph: workspace
  - navigation:
    - link "Atlas":
      - /url: /atlas
    - link "Resources":
      - /url: /resources
    - link "Activity":
      - /url: /activity
  - link "Definition recovery":
    - /url: /recovery/definition
  - paragraph: Built-in revision 1
  - text: Preview density
  - combobox "Preview density":
    - option "From definition"
    - option "Comfortable"
    - option "Compact" [selected]
- complementary: Realm 45 · All authorized processes · shared read principal
- navigation "Declared navigation":
  - link "Open resources":
    - /url: /resources
- main:
  - navigation "Board navigation":
    - link "Process directory":
      - /url: /?status=all&sort=pid
    - text: ·
    - link "Resource directory":
      - /url: /resources
  - paragraph: TRANSIT / AUTHORIZED NEIGHBORHOOD
  - heading "Data workspace" [level=1]
  - paragraph: One draft. One identified result. Two views.
  - button "Canvas" [pressed]
  - button "Browse"
  - region "Unified query workspace":
    - button "← Neighborhood"
    - text: Resource 22 · separate v1 query capability
    - button "Refresh query access" [disabled]
    - status: Checking current query evidence…
    - group "Live draft controls":
      - text: Live draft · finite Table snapshots
      - paragraph: paused · Paused locally; native closure remains observable independently of query completion.
      - text: Evaluation intents
      - combobox "Live draft starts":
        - option "1"
        - option "2" [selected]
        - option "4"
        - option "8"
      - button "Enable Live draft" [disabled]
      - button "Pause Live draft" [disabled]
      - text: Restore draft recovery
      - button "Restore draft recovery" [disabled]
    - paragraph: Retained query 694018368564279231. Current status and cancellation use its original identity even when this screen's binding changes.
    - button "Read retained query status" [disabled]
    - button "Cancel retained query" [disabled]
    - button "Save reference and use current binding" [disabled]
    - paragraph: Switching saves a read reference and clears the selected result. It neither runs a new query nor retires the previous one.
    - strong: Submission not yet confirmed.
    - paragraph: The identical signed request is retained across Board navigation in this tab.
    - button "Retry exact submission" [disabled]
    - text: Existing query namespace
    - textbox "Existing query namespace"
    - button "Resume without rerunning" [disabled]
    - heading "items · table" [level=2]
    - paragraph: Resource revision 173 · policy 1
    - paragraph: Statement ≤ 4096 bytes. Star or up to 128 named columns; comparisons and exact cell-state tests with NOT, AND, OR and parentheses; rows, count, checked int64 sum. Uint64/float64 literals use explicit type suffixes. Writes are unsupported.
    - paragraph: "Budgets: 4096 pages · 63 segments · 245760 result bytes."
    - list:
      - listitem: "id: INT64"
      - listitem: "value: INT64"
    - list "Query steps":
      - listitem: Declared table source
      - listitem: Filter → limit → rows
      - listitem: Verified nested Arrow result
    - group: Complete a draft from the authorized source
    - text: SQL draft
    - textbox "SQL draft": SELECT value FROM items WHERE value = 9007199254740994 LIMIT 1
    - paragraph: Ctrl-Space completes at the cursor. Arrows select, Tab accepts, Escape dismisses and Ctrl-Z undoes acceptance. Completion only edits the draft.
    - button "Complete SQL"
    - button "Run query" [disabled]
    - button "Inspect SQL" [disabled]
    - paragraph: Inspect SQL accepts DESCRIBE, SHOW TABLES and EXPLAIN SELECT.
    - button "Cancel query" [disabled]
    - button "Retire request" [disabled]
    - button "Collect request" [disabled]
```

# Test source

```ts
  35  |   await page.getByLabel("Search this authorized page").fill("");
  36  |   await page.getByRole("button", { name: "Inspect participation", exact: true }).click();
  37  |   await expect(
  38  |     page.getByRole("table", {
  39  |       name: `Authorized associations to resource ${process.env.BOARD_QUERY_RESOURCE}`,
  40  |     }),
  41  |   ).toBeVisible({ timeout: 15000 });
  42  |   const participation = page.getByLabel("Resource participation");
  43  |   const participationDeadline = Date.now() + 15000;
  44  |   for (;;) {
  45  |     expect(Date.now()).toBeLessThan(participationDeadline);
  46  |     const next = page.getByRole("button", { name: /^Next associations for PID/ });
  47  |     await expect(next).toBeVisible();
  48  |     const pending = page.waitForResponse((response) => {
  49  |       const url = new URL(response.url());
  50  |       return url.pathname.endsWith("/participation") && url.searchParams.has("pid");
  51  |     });
  52  |     await next.click();
  53  |     const response = await pending;
  54  |     if (response.status() === 200) break;
  55  |     expect(response.status()).toBe(409);
  56  |     expect((await response.json()).err).toBe("QueryExpired");
  57  |     // Worker progress can invalidate this read-only observation between pages.
  58  |     // Discard its rows and explicitly restart; never combine different cuts.
  59  |     await expect(participation.getByRole("table")).toHaveCount(0);
  60  |     await expect(participation).toContainText("inspection.observation_changed");
  61  |     console.log("Board participation: stale continuation cleared; refreshing its observation");
  62  |     await participation.getByRole("button", { name: "Refresh participation", exact: true }).click();
  63  |   }
  64  |   await expect(participation).toContainText("One selected PID.");
  65  |   execFileSync(process.env.BOARD_QUERY_PROOF!, [
  66  |     process.env.BOARD_QUERY_AUTHORITY!,
  67  |     "revoke-inspector-resource",
  68  |     process.env.BOARD_QUERY_CONFIG!,
  69  |   ]);
  70  |   await expect(page.getByLabel("Resource participation")).toHaveCount(0, { timeout: 15000 });
  71  |   execFileSync(process.env.BOARD_QUERY_PROOF!, [
  72  |     process.env.BOARD_QUERY_AUTHORITY!,
  73  |     "restore-inspector-resource",
  74  |     process.env.BOARD_QUERY_CONFIG!,
  75  |   ]);
  76  |   await page.getByRole("button", { name: "Refresh observation", exact: true }).click();
  77  |   await expect(page.getByLabel("Resource participation")).toBeVisible({ timeout: 15000 });
  78  |   for (const density of ["comfortable", "compact"]) {
  79  |     await page.getByLabel("Preview density").selectOption(density);
  80  |     expect(
  81  |       (await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa"]).analyze()).violations,
  82  |     ).toEqual([]);
  83  |   }
  84  |   await page.getByRole("button", { name: "Resources", exact: true }).click();
  85  |   await page.getByLabel("Detail zoom").focus();
  86  |   await page.getByLabel("Detail zoom").press("End");
  87  |   await expect(page.getByLabel("Detail zoom")).toHaveValue("3");
  88  |   await page.screenshot({
  89  |     path: process.env.BOARD_QUERY_SCREENSHOT?.replace(".png", "-atlas.png"),
  90  |     fullPage: true,
  91  |   });
  92  |   await page.getByRole("button", { name: "Enter resource" }).click();
  93  |   const draft = page.getByLabel("SQL draft", { exact: true });
  94  |   await expect(draft).toBeVisible();
  95  |   const sql = "SELECT value FROM items WHERE value = 9007199254740994 LIMIT 1";
  96  |   await draft.fill(sql);
  97  |   await page.getByRole("button", { name: "Browse", exact: true }).click();
  98  |   await expect(draft).toHaveValue(sql);
  99  |   await page.getByRole("button", { name: "Canvas", exact: true }).click();
  100 |   expect(submissions).toBe(0);
  101 |   let dropped = false;
  102 |   const frozen: string[] = [];
  103 |   await page.route("**/api/v1/query", async (route) => {
  104 |     const body = route.request().postDataJSON();
  105 |     if (body.submit) {
  106 |       frozen.push(JSON.stringify(body));
  107 |       if (!dropped) {
  108 |         dropped = true;
  109 |         await route.fetch();
  110 |         await route.abort("failed");
  111 |         return;
  112 |       }
  113 |     }
  114 |     await route.continue();
  115 |   });
  116 |   await page.getByRole("button", { name: "Run query", exact: true }).click();
  117 |   await expect(
  118 |     page.getByRole("button", { name: "Retry exact submission", exact: true }),
  119 |   ).toBeVisible();
  120 |   await page.getByRole("link", { name: "Activity", exact: true }).click();
  121 |   await expect(page.getByRole("heading", { name: "Activity", exact: true })).toBeVisible();
  122 |   await page.getByRole("link", { name: "Atlas", exact: true }).click();
  123 |   await page
  124 |     .getByRole("button", {
  125 |       name: `Select resource ${process.env.BOARD_QUERY_RESOURCE}`,
  126 |       exact: true,
  127 |     })
  128 |     .click();
  129 |   await page.getByRole("button", { name: "Enter resource", exact: true }).click();
  130 |   await expect(
  131 |     page.getByRole("button", { name: "Retry exact submission", exact: true }),
  132 |   ).toBeVisible();
  133 |   await page.getByRole("button", { name: "Retry exact submission", exact: true }).click();
  134 |   expect(frozen[0]).toEqual(frozen[1]);
> 135 |   await expect(page.getByLabel("Verified query result")).toBeVisible({ timeout: 120000 });
      |                                                          ^ Error: expect(locator).toBeVisible() failed
  136 |   await expect(
  137 |     page.getByLabel("Verified query result").getByText("9007199254740994", { exact: true }),
  138 |   ).toBeVisible();
  139 |   await page.getByRole("button", { name: "Browse", exact: true }).click();
  140 |   await expect(draft).toHaveValue(sql);
  141 |   await expect(page.getByRole("cell", { name: "9007199254740994", exact: true })).toBeVisible();
  142 |   const completed = submissions;
  143 |   expect(completed).toBeGreaterThan(2); // finite upload has several committed steps
  144 |   await draft.fill("SELECT id FROM items LIMIT 2");
  145 |   await page.getByRole("button", { name: "Canvas", exact: true }).click();
  146 |   await expect(draft).toHaveValue("SELECT id FROM items LIMIT 2");
  147 |   await expect(
  148 |     page.getByText("Draft changed. The displayed result belongs to the earlier submitted SQL."),
  149 |   ).toBeVisible();
  150 |   expect(submissions).toBe(completed);
  151 |   const recovery = page.getByLabel("Retained query recovery", { exact: true });
  152 |   const reference = await recovery.innerText();
  153 |   const correlation = /Retained query (\d+)\./.exec(reference)?.[1];
  154 |   expect(correlation).toBeTruthy();
  155 |   const download = page.waitForEvent("download");
  156 |   await page.getByRole("button", { name: "Save reference and use current binding" }).click();
  157 |   expect((await download).suggestedFilename()).toBe("transit-query-reference.json");
  158 |   await expect(page.getByLabel("Verified query result")).toHaveCount(0);
  159 |   await expect(page.getByRole("button", { name: "Run query", exact: true })).toBeEnabled();
  160 |   await page.getByLabel("Existing query namespace", { exact: true }).fill(correlation!);
  161 |   await page.getByRole("button", { name: "Resume without rerunning", exact: true }).click();
  162 |   await expect(page.getByLabel("Verified query result")).toBeVisible();
  163 |   expect(submissions).toBe(completed);
  164 |   await page.screenshot({ path: process.env.BOARD_QUERY_SCREENSHOT, fullPage: true });
  165 |   execFileSync(process.env.BOARD_QUERY_PROOF!, [
  166 |     process.env.BOARD_QUERY_AUTHORITY!,
  167 |     "revoke",
  168 |     process.env.BOARD_QUERY_CONFIG!,
  169 |   ]);
  170 |   await expect(
  171 |     page.getByText("Query access denied. Protected workspace data cleared."),
  172 |   ).toBeVisible({ timeout: 15000 });
  173 |   await expect(page.getByLabel("Verified query result")).toHaveCount(0);
  174 |   await expect(draft).toHaveCount(0);
  175 |   expect(submissions).toBe(completed);
  176 |   expect(await context.cookies()).toEqual([]);
  177 |   expect(await page.evaluate(() => [localStorage.length, sessionStorage.length])).toEqual([0, 0]);
  178 |   execFileSync(process.env.BOARD_QUERY_PROOF!, [
  179 |     process.env.BOARD_QUERY_AUTHORITY!,
  180 |     "restore",
  181 |     process.env.BOARD_QUERY_CONFIG!,
  182 |   ]);
  183 |   const clearedPageReads = pageReads;
  184 |   await page.getByRole("button", { name: "Refresh query access" }).click();
  185 |   await expect(draft).toHaveValue("SELECT * FROM items");
  186 |   // Wait for the complete access/status refresh, not just its early source update.
  187 |   await expect(page.getByRole("button", { name: "Run query", exact: true })).toBeEnabled();
  188 |   await expect(recovery).toContainText(`Retained query ${correlation}.`);
  189 |   await expect(page.getByLabel("Verified query result")).toHaveCount(0);
  190 |   expect(pageReads).toBe(clearedPageReads);
  191 |   await page.getByLabel("Existing query namespace", { exact: true }).fill(correlation!);
  192 |   await page.getByRole("button", { name: "Resume without rerunning", exact: true }).click();
  193 |   await expect(page.getByLabel("Verified query result")).toBeVisible();
  194 |   await expect(
  195 |     page.getByLabel("Verified query result").getByText("9007199254740994", { exact: true }),
  196 |   ).toBeVisible();
  197 |   await expect(
  198 |     page.getByText("Draft changed. The displayed result belongs to the earlier submitted SQL."),
  199 |   ).toBeVisible();
  200 |   expect(pageReads).toBeGreaterThan(clearedPageReads);
  201 |   expect(submissions).toBe(completed);
  202 |   expect(errors).toEqual([]);
  203 |   execFileSync(process.env.BOARD_QUERY_PROOF!, [
  204 |     process.env.BOARD_QUERY_AUTHORITY!,
  205 |     "retire-source",
  206 |     process.env.BOARD_QUERY_CONFIG!,
  207 |   ]);
  208 |   await expect(
  209 |     page.getByText("Source or result unavailable. Protected workspace data cleared."),
  210 |   ).toBeVisible({ timeout: 15000 });
  211 |   await expect(draft).toHaveCount(0);
  212 |   await expect(page.getByLabel("Verified query result")).toHaveCount(0);
  213 | });
  214 | 
```