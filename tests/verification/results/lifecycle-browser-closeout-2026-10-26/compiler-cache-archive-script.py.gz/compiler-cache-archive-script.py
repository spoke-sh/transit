import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

roots = [
    Path('/var/tmp/transit-lifecycle-final-check-6c7n489w/src'),
    Path('/var/tmp/transit-lifecycle-final-check-0xoh8zcd/src'),
    Path('/var/tmp/transit-ci-4rnkyjsk/src'),
    Path('/var/tmp/transit-ci-1i_p0qyl/src'),
    Path('/var/tmp/transit-ci-5tly1g0s/src'),
]
destination = Path('/var/tmp/transit-lifecycle-compiler-archives')
destination.mkdir(exist_ok=True)
manifest = destination / 'manifest.json'
assert not manifest.exists()
report = {'method': 'Lossless archive of inactive compiler caches only; source, proof evidence, fixtures and original uncertain SQL installations remain in place. Every regular file and symlink is checked against its pre-archive digest/target before removing the unpacked cache.', 'roots': []}

def save():
    manifest.write_text(json.dumps(report, indent=2) + '\n')

def digest(stream):
    value = hashlib.sha256()
    while chunk := stream.read(1024 * 1024):
        value.update(chunk)
    return value.hexdigest()

def inactive(root):
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            command = (proc / 'cmdline').read_bytes()
        except OSError:
            command = b''
        paths = []
        for name in ['cwd', 'exe']:
            try:
                paths.append(os.readlink(proc / name))
            except OSError:
                pass
        assert str(root).encode() not in command and not any(path == str(root) or path.startswith(str(root) + '/') for path in paths), ('active checkout', str(root), proc.name)

for root in roots:
    inactive(root)
    cache = root / '.zig-cache'
    assert cache.is_dir() and not cache.is_symlink()
    revision = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
    origin = subprocess.check_output(['git', '-C', str(root), 'config', '--get', 'remote.origin.url'], text=True).strip()
    assert origin in ['/home/alex/workspace/rupurt/rey', '/var/tmp/transit-named-resource-release']
    files = {}
    print('Hashing', root, flush=True)
    for path in sorted(cache.rglob('*')):
        relative = str(path.relative_to(root))
        if path.is_symlink():
            files[relative] = {'link': os.readlink(path)}
        elif path.is_file():
            with path.open('rb') as stream:
                files[relative] = {'sha256': digest(stream), 'bytes': path.stat().st_size}
    index = destination / (root.parent.name + '.files.json')
    index.write_text(json.dumps(files, indent=2) + '\n')
    archive = destination / (root.parent.name + '.tar.zst')
    assert not archive.exists()
    entry = {'root': str(root), 'revision': revision, 'origin': origin, 'index': str(index), 'archive': str(archive), 'bytes': sum(value.get('bytes', 0) for value in files.values()), 'verified': False, 'unpacked_removed': False}
    report['roots'].append(entry)
    save()
    print('Archiving', root, entry['bytes'], flush=True)
    subprocess.run(['tar', '--use-compress-program=zstd -T4 -3', '-cf', str(archive), '-C', str(root), '.zig-cache'], check=True)
    seen = set()
    print('Verifying', archive, flush=True)
    process = subprocess.Popen(['zstd', '-dc', str(archive)], stdout=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdout, mode='r|') as bundle:
        for member in bundle:
            if member.isdir():
                continue
            assert member.name in files and member.name not in seen
            expected = files[member.name]
            if member.issym():
                assert expected == {'link': member.linkname}
            elif member.islnk():
                assert files[member.linkname] == expected
            else:
                assert member.isfile() and expected['bytes'] == member.size
                assert digest(bundle.extractfile(member)) == expected['sha256'], member.name
            seen.add(member.name)
    process.stdout.close()
    assert process.wait() == 0 and seen == set(files)
    with archive.open('rb') as stream:
        entry['archive_sha256'] = digest(stream)
    with index.open('rb') as stream:
        entry['index_sha256'] = digest(stream)
    entry.update(verified=True, archive_bytes=archive.stat().st_size)
    save()
    inactive(root)
    shutil.rmtree(cache)
    entry['unpacked_removed'] = True
    entry['free_bytes_after'] = shutil.disk_usage(destination).free
    save()
    print('Archived and removed unpacked cache', root, 'free bytes', entry['free_bytes_after'], flush=True)

print('Done', flush=True)
