import json, os, subprocess, sys
from pathlib import Path
root=Path('/home/alex/workspace/rupurt/rey')
baseline=Path('/var/tmp/rey-storage-baseline-ee88a131')
harness=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
current_source='fc79844f053760ff22ff5ae8bd9ce95b3f41ab2b'
old='ee88a131d6d76471683c2e6120a88907d7edf333'
current=root/'.cache/storage-foundation/bin'
previous=baseline/'.cache/storage-baseline/bin'
runs=[]
for name,binaries,source in [('baseline',previous,old),('foundation',current,current_source)]:
 for kind,repeat,extra in [('reads',20,[]),('read-counts',1,['--instrument'])]:
  label=name+'-'+kind+'-supported'
  output=Path('/var/tmp/rey-storage-'+label+'.json')
  assert not output.exists(),output
  runs.append((label,[sys.executable,'tests/mutation_latency.py',*(str(binaries/x) for x in ('transit','transit-node','transit-query-host')),'--output',str(output),'--build-revision',source,'--repeat','1','--rows','32','--age','32','--read-repeat',str(repeat),*extra],source))
for name,binaries,source in [('baseline',baseline/'.cache/storage-baseline/sql-wire/bin',old),('foundation',current,current_source)]:
 runs.append((name+'-wire',[sys.executable,'tests/sql_wire/gateway.py',*(str(binaries/x) for x in ('transit-node','transit-typed-table-proof','transit-sql-gateway-proof','transit-query-host','transit-sql-gateway','transit-configuration-probe')),'benchmark'],source))
manifest=[]
for name,command,source in runs:
 print('Starting '+name,flush=True)
 log=Path('/var/tmp/rey-storage-'+name+'.log')
 assert not log.exists(),log
 with log.open('w') as target:
  completed=subprocess.run(command,cwd=root,stdout=target,stderr=subprocess.STDOUT,env=os.environ|{'TRANSIT_BENCH_BUILD_REVISION':source})
 manifest.append(dict(name=name,command=command,build_revision=source,code=completed.returncode,log=str(log)))
 Path('/var/tmp/rey-storage-foundation-reads-campaign.json').write_text(json.dumps(dict(harness_revision=harness,runs=manifest),indent=2)+'\n')
 print('Finished '+name+': '+str(completed.returncode),flush=True)
raise SystemExit(any(r['code'] for r in manifest))
