import json, os, subprocess, sys
from pathlib import Path
root=Path('/home/alex/workspace/rupurt/rey')
baseline=Path('/var/tmp/rey-storage-baseline-ee88a131')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
old='ee88a131d6d76471683c2e6120a88907d7edf333'
current=root/'.cache/storage-foundation/bin'
previous=baseline/'.cache/storage-baseline/bin'
runs=[]
def console(name, binaries, source, *options):
 output=Path('/var/tmp/rey-storage-'+name+'.json')
 assert not output.exists(),output
 runs.append((name,[sys.executable,'tests/mutation_latency.py',*(str(binaries/x) for x in ('transit','transit-node','transit-query-host')),'--output',str(output),'--build-revision',source,*options],source))
for name, options in [('narrow',['--repeat','20']),('wide',['--repeat','3','--schema-profile','wide']),('nested',['--repeat','3','--schema-profile','nested']),('retained',['--repeat','3','--rows','32','--age','32','--readers','1']),('counts',['--repeat','1','--instrument'])]:
 console('foundation-'+name,current,revision,*options)
for name,binaries,source in [('baseline',previous,old),('foundation',current,revision)]:
 console(name+'-reads',binaries,source,'--repeat','1','--rows','32','--age','32','--read-repeat','20')
 console(name+'-read-counts',binaries,source,'--repeat','1','--rows','32','--age','32','--read-repeat','1','--instrument')
for name,binaries,source in [('baseline',baseline/'.cache/storage-baseline/sql-wire/bin',old),('foundation',current,revision)]:
 runs.append((name+'-wire',[sys.executable,'tests/sql_wire/gateway.py',*(str(binaries/x) for x in ('transit-node','transit-typed-table-proof','transit-sql-gateway-proof','transit-query-host','transit-sql-gateway','transit-configuration-probe')),'benchmark'],source))
manifest=[]
for name,command,source in runs:
 print('Starting '+name,flush=True)
 log=Path('/var/tmp/rey-storage-'+name+'.log')
 with log.open('w') as target:
  completed=subprocess.run(command,cwd=root,stdout=target,stderr=subprocess.STDOUT,env=os.environ|{'TRANSIT_BENCH_BUILD_REVISION':source})
 manifest.append(dict(name=name,command=command,build_revision=source,code=completed.returncode,log=str(log)))
 Path('/var/tmp/rey-storage-foundation-campaign.json').write_text(json.dumps(dict(harness_revision=revision,runs=manifest),indent=2)+'\n')
 print('Finished '+name+': '+str(completed.returncode),flush=True)
raise SystemExit(any(r['code'] for r in manifest))
