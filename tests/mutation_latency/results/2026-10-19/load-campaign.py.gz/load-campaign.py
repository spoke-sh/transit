import json
import subprocess
import time
from pathlib import Path

root=Path('/home/alex/workspace/rupurt/rey')
parent=Path('/proc/25892')
while parent.exists():
    try:
        command=(parent/'cmdline').read_bytes()
    except FileNotFoundError:
        break
    if b'/var/tmp/rey-storage-final-campaign.py' not in command:
        raise RuntimeError('Timed campaign PID identity changed')
    time.sleep(5)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
manifest=[]
for name,cwd in [('baseline',Path('/var/tmp/rey-storage-baseline-ee88a131')),('final',root)]:
    output=Path('/var/tmp/rey-storage-'+name+'-load.json')
    log=Path('/var/tmp/rey-storage-'+name+'-load.log')
    assert not output.exists() and not log.exists()
    command=['nix','develop','--command','zig','build','test-growing-load','-Doptimize=ReleaseSafe','--','--output',str(output)]
    print('Starting '+name+' offered load',flush=True)
    with log.open('w') as target:
        result=subprocess.run(command,cwd=cwd,stdout=target,stderr=subprocess.STDOUT)
    manifest.append(dict(name=name,command=command,cwd=str(cwd),code=result.returncode,log=str(log),output=str(output)))
    Path('/var/tmp/rey-storage-load-campaign.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('Finished '+name+' offered load: '+str(result.returncode),flush=True)
raise SystemExit(any(run['code'] for run in manifest))
