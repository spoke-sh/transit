//! Owned logical SELECT templates. Parameters bind to typed operands, never SQL
//! text. The source owner supplies and authorizes the immutable binding separately.
const std = @import("std");
const t = @import("Types.zig");
const sql = @import("Sql.zig");
const Parser = @import("SqlTyped.zig");
const Select = @import("TableSelect.zig");
const codec = @import("LogicalPlanCodec.zig");
const Self = @This();
pub const max_parameters = @import("LogicalPredicate.zig").Program.max_instructions + 1;
pub const Bound = codec.Owned;
arena: std.heap.ArenaAllocator,
descriptor: t.Decoded,
syntax: Select.Syntax,
name: []const u8,
basis: [32]u8,
types: [max_parameters]t.Type = undefined,
sites: [max_parameters]?sql.Parameter = @splat(null),
count: u8 = 0,
extra: []const Parameter = &.{},
pub const Parameter = struct { site: sql.Parameter, type: t.Type };

pub fn init(allocator: std.mem.Allocator, text: []const u8, name: []const u8, schema: t.Type, basis: [32]u8, diagnostic: ?*sql.Binding) !Self {
    return initDialect(allocator, text, name, schema, basis, diagnostic, .transit);
}
pub fn initDialect(allocator: std.mem.Allocator, text: []const u8, name: []const u8, schema: t.Type, basis: [32]u8, diagnostic: ?*sql.Binding, dialect: sql.Dialect) !Self {
    return initSemantics(allocator, text, name, schema, basis, diagnostic, dialect, &.{});
}
pub fn initSemantics(allocator: std.mem.Allocator, text: []const u8, name: []const u8, schema: t.Type, basis: [32]u8, diagnostic: ?*sql.Binding, dialect: sql.Dialect, semantics: []const @import("ColumnSemantics.zig")) !Self {
    return initInner(allocator, text, name, schema, basis, diagnostic, dialect, semantics) catch |err| {
        if (diagnostic) |detail| if (detail.location) |position| sql.Binding.nameFailure(detail, text, name, err, position);
        return err;
    };
}
fn initInner(allocator: std.mem.Allocator, text: []const u8, name: []const u8, schema: t.Type, basis: [32]u8, diagnostic: ?*sql.Binding, dialect: sql.Dialect, semantics: []const @import("ColumnSemantics.zig")) !Self {
    if (diagnostic) |detail| detail.* = .{};
    try sql.validateText(text);
    if (schema != .structure or schema.structure.len == 0 or schema.structure.len > 128) return error.InvalidQuerySchema;
    var descriptor = try schema.clone(allocator);
    errdefer descriptor.deinit();
    var arena: std.heap.ArenaAllocator = .init(allocator);
    defer arena.deinit();
    const alloc = arena.allocator();
    // Numeric literal tokens borrow lexer text; retain all text before parsing.
    const owned_text = try alloc.dupe(u8, text);
    var location: sql.Location = .{};
    errdefer if (diagnostic) |detail| {
        if (detail.location == null) detail.location = location;
    };
    var parser = try Parser.initDialect(alloc, owned_text, &location, true, dialect);
    var syntax = try Select.syntax(&parser, descriptor.type);
    if (semantics.len != 0 and semantics.len != schema.structure.len) return error.InvalidColumnSemantics;
    const owned_semantics = try alloc.dupe(@import("ColumnSemantics.zig"), semantics);
    for (owned_semantics, 0..) |*item, i| {
        try item.validate(schema.structure[i].type);
        if (item.timezone) |rules| item.timezone = try rules.cloneInto(alloc);
    }
    syntax.semantics = owned_semantics;
    try parser.finish();
    return adoptOwned(&arena, descriptor, syntax, name, basis, &.{}, &location, diagnostic) catch |err| {
        sql.Binding.nameFailure(diagnostic, owned_text, if (err == error.UnknownSource) name else syntax.qualifier, err, location);
        return err;
    };
}

/// Adopt shared projection/predicate syntax parsed by a dedicated workload
/// compiler. Syntax and all borrowed text must belong to `arena`. Success moves
/// the arena and resets its caller; failure leaves caller cleanup intact.
/// Metadata operands share parameter type/gap checks with predicate operands.
pub fn adoptSyntax(allocator: std.mem.Allocator, arena: *std.heap.ArenaAllocator, syntax: Select.Syntax, name: []const u8, schema: t.Type, basis: [32]u8, extra: []const Parameter, diagnostic: ?*sql.Binding) !Self {
    if (diagnostic) |detail| detail.* = .{};
    if (schema != .structure or schema.structure.len == 0 or schema.structure.len > 128) return error.InvalidQuerySchema;
    var descriptor = try schema.clone(allocator);
    errdefer descriptor.deinit();
    var location: sql.Location = .{};
    errdefer if (diagnostic) |detail| {
        if (detail.location == null) detail.location = location;
    };
    return adoptOwned(arena, descriptor, syntax, name, basis, extra, &location, diagnostic);
}
fn adoptOwned(arena: *std.heap.ArenaAllocator, descriptor: t.Decoded, syntax: Select.Syntax, name: []const u8, basis: [32]u8, extra: []const Parameter, location: *sql.Location, diagnostic: ?*sql.Binding) !Self {
    const alloc = arena.allocator();
    var result: Self = .{ .arena = undefined, .descriptor = descriptor, .syntax = syntax, .name = try alloc.dupe(u8, name), .basis = basis };
    const parameters = try alloc.alloc(Parameter, extra.len);
    for (extra, parameters) |input, *output| output.* = .{ .site = input.site, .type = try input.type.cloneInto(alloc) };
    result.extra = parameters;
    if (syntax.predicate) |predicate| for (predicate.instructions) |instruction| {
        if (instruction != .atom or instruction.atom != .compare) continue;
        const compare = instruction.atom.compare;
        if (compare.value != .parameter) continue;
        const column = try compare.column.resolve(syntax.qualifier, descriptor.type.structure, location);
        try result.register(compare.value.parameter, descriptor.type.structure[column].type, diagnostic);
    };
    if (syntax.limit_parameter) |site| try result.register(site, .uint64, diagnostic);
    for (parameters) |parameter| try result.register(parameter.site, parameter.type, diagnostic);
    for (result.sites[0..result.count], 0..) |site, i| if (site == null) {
        if (diagnostic) |detail| detail.missing_parameter = @intCast(i + 1);
        return error.ParameterGap;
    };
    var witnesses: [max_parameters]?t.Values.Atom = undefined;
    if (diagnostic) |detail| detail.* = .{};
    for (result.parameterTypes(), witnesses[0..result.count], 0..) |kind, *value, i| value.* = witness(kind) catch |err| {
        result.at(@intCast(i + 1), diagnostic);
        if (diagnostic) |detail| detail.expected = @tagName(kind);
        return err;
    };
    _ = try syntax.bindParametersDiagnostic(alloc, name, descriptor.type, basis, location, witnesses[0..result.count], diagnostic);
    // Transfer only the final arena state, including validation allocations.
    // Syntax retains no diagnostic pointer.
    result.arena = arena.*;
    arena.* = .init(arena.child_allocator);
    return result;
}
pub fn deinit(self: *Self) void {
    self.arena.deinit();
    self.descriptor.deinit();
    self.* = undefined;
}
pub fn parameterTypes(self: *const Self) []const t.Type {
    return self.types[0..self.count];
}
/// Describe a template without source acquisition or execution. Typed witnesses
/// determine only the output shape; callers still bind the real values later.
pub fn outputSchema(self: *const Self, allocator: std.mem.Allocator) !t.Decoded {
    var values: [max_parameters]?t.Values.Atom = undefined;
    for (self.parameterTypes(), values[0..self.count]) |kind, *value| value.* = try witness(kind);
    var bound = try self.bind(allocator, self.name, self.descriptor.type, self.basis, values[0..self.count], null);
    defer bound.deinit();
    var fields: [128]t.Field = undefined;
    return (try bound.plan.outputSchema(&fields)).clone(allocator);
}
fn at(self: *const Self, index: u32, diagnostic: ?*sql.Binding) void {
    const detail = diagnostic orelse return;
    detail.parameter = index;
    detail.parameter_sites = @splat(null);
    var count: usize = 0;
    if (self.syntax.predicate) |predicate| for (predicate.instructions) |instruction| {
        if (instruction != .atom or instruction.atom != .compare or instruction.atom.compare.value != .parameter) continue;
        const site = instruction.atom.compare.value.parameter;
        if (site.index == index and count < detail.parameter_sites.len) {
            detail.parameter_sites[count] = site.offset;
            count += 1;
        }
    };
    if (self.syntax.limit_parameter) |site| if (site.index == index and count < detail.parameter_sites.len) {
        detail.parameter_sites[count] = site.offset;
        count += 1;
    };
    for (self.extra) |parameter| if (parameter.site.index == index and count < detail.parameter_sites.len) {
        detail.parameter_sites[count] = parameter.site.offset;
        count += 1;
    };
    if (count != 0) detail.location = .{ .offset = detail.parameter_sites[0].? };
}
fn register(self: *Self, site: sql.Parameter, kind: t.Type, diagnostic: ?*sql.Binding) !void {
    self.at(site.index, diagnostic);
    if (diagnostic) |detail| detail.location = .{ .offset = site.offset };
    if (site.index == 0) return error.InvalidParameterIndex;
    if (site.index > max_parameters) {
        if (diagnostic) |detail| {
            for (self.sites, 0..) |used, i| if (used == null) {
                detail.missing_parameter = @intCast(i + 1);
                break;
            };
        }
        return error.ParameterGap;
    }
    const index = site.index - 1;
    if (self.sites[index] != null and !try self.types[index].eql(kind)) {
        if (diagnostic) |detail| {
            detail.expected = @tagName(self.types[index]);
            detail.actual = @tagName(kind);
        }
        return error.ParameterTypeConflict;
    }
    self.sites[index] = self.sites[index] orelse site;
    self.types[index] = kind;
    self.count = @max(self.count, @as(u8, @intCast(site.index)));
}
/// Supplied schema/name/basis must match the template's exact immutable source.
/// Current rights and a new admission are still the source owner's responsibility.
/// All successful descriptors, names and values belong to the returned owner.
pub fn bind(self: *const Self, allocator: std.mem.Allocator, name: []const u8, schema: t.Type, basis: [32]u8, values: []const ?t.Values.Atom, diagnostic: ?*sql.Binding) !Bound {
    return self.instantiate(allocator, name, schema, basis, basis, values, diagnostic);
}
/// Instantiate a new execution after the source owner checks the immutable
/// preparation identity and authorizes a fresh captured cut. Both identities
/// are explicit: the template's basis equality remains mandatory. No saved plan
/// is mutated, rebound or reused as recovery material by this operation.
pub fn instantiate(self: *const Self, allocator: std.mem.Allocator, name: []const u8, schema: t.Type, basis: [32]u8, captured_basis: [32]u8, values: []const ?t.Values.Atom, diagnostic: ?*sql.Binding) !Bound {
    if (diagnostic) |detail| detail.* = .{};
    const expected = try self.descriptor.type.fingerprint();
    const observed = try schema.fingerprint();
    if (!std.mem.eql(u8, name, self.name) or !std.mem.eql(u8, &basis, &self.basis) or !std.mem.eql(u8, &expected, &observed)) {
        if (diagnostic) |detail| {
            detail.expected_schema = expected;
            detail.actual_schema = observed;
        }
        return error.SourceChanged;
    }
    if (values.len != self.count) {
        if (diagnostic) |detail| {
            detail.expected_count = self.count;
            detail.actual_count = values.len;
        }
        return error.ParameterCountMismatch;
    }
    for (values, self.parameterTypes(), 0..) |optional, kind, i| {
        const value = optional orelse continue;
        validate(value, kind) catch |err| {
            self.at(@intCast(i + 1), diagnostic);
            if (diagnostic) |detail| {
                detail.expected = @tagName(kind);
                detail.actual = @tagName(value);
                sql.Binding.suppliedLogical(detail, value);
            }
            return err;
        };
    }
    var arena: std.heap.ArenaAllocator = .init(allocator);
    defer arena.deinit();
    var location: sql.Location = .{};
    errdefer if (diagnostic) |detail| {
        if (detail.location == null) detail.location = location;
    };
    const plan = try self.syntax.bindParametersDiagnostic(arena.allocator(), name, schema, captured_basis, &location, values, diagnostic);
    var bytes: [codec.max_bytes]u8 = undefined;
    return codec.decode(allocator, schema, captured_basis, try codec.encode(plan, &bytes));
}
pub fn validate(value: t.Values.Atom, kind: t.Type) !void {
    try @import("SqlLogicalPredicate.zig").validateParameter(value, kind);
}

pub fn witness(kind: t.Type) !t.Values.Atom {
    return switch (kind) {
        .int8, .int16, .int32, .int64, .int128 => .{ .signed = 0 },
        .uint8, .uint16, .uint32, .uint64, .uint128 => .{ .unsigned = 0 },
        .float32, .float64 => .{ .float = 0 },
        .decimal => .{ .decimal = 0 },
        .boolean => .{ .boolean = false },
        .utf8, .binary => .{ .bytes = "" },
        .date => .{ .date = 0 },
        .time => .{ .time = 0 },
        .timestamp => .{ .timestamp = 0 },
        .uuid => .{ .uuid = @splat(0) },
        else => error.UnsupportedComparison,
    };
}
