const std = @import("std");
pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    inline for (.{ "transit_sql_frontend", "transit_protocol", "transit_memory", "transit_spatial", "transit_test_protocol" }) |name| {
        b.modules.put(b.allocator, name, b.dependency(name, .{ .target = target, .optimize = optimize }).module(name)) catch @panic("out of memory");
    }
}
